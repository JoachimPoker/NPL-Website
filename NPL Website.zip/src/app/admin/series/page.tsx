"use client";

import { useEffect, useState } from "react";

type Series = {
  id?: number;
  slug?: string;
  name: string;
  keywords: string[];
  is_active: boolean;
  notes?: string | null;
  created_at?: string;
  updated_at?: string;
};

async function jsonOrText(res: Response) {
  const txt = await res.text();
  try { return JSON.parse(txt); } catch { return { _raw: txt }; }
}

export default function AdminSeriesPage() {
  const [list, setList] = useState<Series[]>([]);
  const [editing, setEditing] = useState<Series | null>(null);
  const [err, setErr] = useState<string | null>(null);
  const [ok, setOk] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);

  const load = async () => {
    setErr(null);
    setLoading(true);
    try {
      const res = await fetch("/api/admin/series/list", { cache: "no-store" });
      const data = await jsonOrText(res);
      if (!res.ok) throw new Error(data?._error || data?._raw || res.statusText);
      setList(data.series || []);
    } catch (e: any) {
      setErr(e?.message || String(e));
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => { load(); }, []);

  const startNew = () => {
    setEditing({ name: "", keywords: [], is_active: true, notes: "" });
    setOk(null); setErr(null);
  };

  const startEdit = (s: Series) => {
    setEditing({ ...s, keywords: (s.keywords || []).slice() });
    setOk(null); setErr(null);
  };

  const save = async () => {
    if (!editing) return;
    setErr(null); setOk(null); setLoading(true);
    try {
      const body = {
        id: editing.id ?? null,
        name: editing.name.trim(),
        slug: editing.slug?.trim(),
        keywords: (editing.keywords || []).map(k => k.toLowerCase().trim()).filter(Boolean),
        is_active: editing.is_active,
        notes: editing.notes || "",
      };
      const res = await fetch("/api/admin/series/upsert", {
        method: "POST",
        headers: { "content-type": "application/json" },
        body: JSON.stringify(body),
      });
      const data = await jsonOrText(res);
      if (!res.ok) throw new Error(data?._error || data?._raw || res.statusText);
      setOk("Saved.");
      setEditing(null);
      load();
    } catch (e: any) {
      setErr(e?.message || String(e));
    } finally { setLoading(false); }
  };

  const remove = async (id: number) => {
    if (!confirm("Delete this series?")) return;
    setErr(null); setOk(null); setLoading(true);
    try {
      const res = await fetch("/api/admin/series/delete", {
        method: "POST",
        headers: { "content-type": "application/json" },
        body: JSON.stringify({ id }),
      });
      const data = await jsonOrText(res);
      if (!res.ok) throw new Error(data?._error || data?._raw || res.statusText);
      setOk("Deleted.");
      load();
    } catch (e: any) {
      setErr(e?.message || String(e));
    } finally { setLoading(false); }
  };

  const runAutoAll = async () => {
    setErr(null); setOk(null); setLoading(true);
    try {
      const res = await fetch("/api/admin/series/auto-assign-all", { method: "POST" });
      const data = await jsonOrText(res);
      if (!res.ok) throw new Error(data?._error || data?._raw || res.statusText);
      alert(
        `All-series auto-assign complete.
Assigned: ${data.assigned_events}
Festivals created: ${data.created_festivals}
Events updated: ${data.updated_events}`
      );
      await load();
    } catch (e:any) {
      setErr(e?.message || String(e));
    } finally { setLoading(false); }
  };

  return (
    <div className="p-4 space-y-6">
      <div className="flex items-center justify-between">
        <h1 className="text-xl font-semibold">Admin — Series</h1>
        <div className="flex gap-3">
          <a className="text-sm underline" href="/admin/seasons">Seasons</a>
          <a className="text-sm underline" href="/admin/import">Import</a>
          <button className="border rounded px-3 py-1" onClick={runAutoAll}>Auto-assign all</button>
          <button className="border rounded px-3 py-1" onClick={startNew}>+ New Series</button>
        </div>
      </div>

      {err && <div className="p-2 bg-red-100 text-red-700 text-sm rounded">{err}</div>}
      {ok && <div className="p-2 bg-green-100 text-green-700 text-sm rounded">{ok}</div>}

      {editing && (
        <div className="border rounded p-4 space-y-4 bg-white">
          {/* form fields… (unchanged from yours) */}
          {/* ... */}
        </div>
      )}

      <div className="border rounded bg-white overflow-hidden">
        <div className="px-4 py-3 border-b flex items-center justify-between">
          <b>Series</b>
          <button className="text-sm underline" onClick={load} disabled={loading}>Refresh</button>
        </div>
        <div className="p-4 overflow-x-auto">
          {!list.length ? (
            <p className="text-sm text-gray-600">No series yet.</p>
          ) : (
            <table>
              <thead>
                <tr>
                  <th className="text-left">Name</th>
                  <th className="text-left">Slug</th>
                  <th className="text-left">Keywords</th>
                  <th className="text-left">Active</th>
                  <th className="text-left w-40">Actions</th>
                </tr>
              </thead>
              <tbody>
                {list.map((s) => (
                  <tr key={s.id}>
                    <td>{s.name}</td>
                    <td>{s.slug}</td>
                    <td>{(s.keywords || []).join(", ")}</td>
                    <td>{s.is_active ? "✅" : "—"}</td>
                    <td>
                      <div className="flex gap-2">
                        <a className="border rounded px-2 py-1 text-sm" href={`/admin/series/${s.id}`}>Manage</a>
                        <button className="border rounded px-2 py-1 text-sm" onClick={() => startEdit(s)}>Edit</button>
                        <button className="border rounded px-2 py-1 text-sm" onClick={() => s.id && remove(s.id)}>Delete</button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          )}
        </div>
      </div>
    </div>
  );
}
