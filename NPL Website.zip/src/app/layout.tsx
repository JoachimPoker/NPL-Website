// src/app/layout.tsx
import "./globals.css";

export const metadata = {
  title: "National Poker League",
  description: "Official standings and stats",
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <body className="min-h-screen bg-gray-50 text-gray-900">
        <header className="px-4 py-3 border-b bg-white">
          <div className="max-w-6xl mx-auto flex items-center justify-between">
            <a href="/" className="font-semibold">National Poker League</a>
            <nav className="text-sm">
              <a className="underline" href="/admin">Admin</a>
            </nav>
          </div>
        </header>
        <main className="max-w-6xl mx-auto p-4">{children}</main>
      </body>
    </html>
  );
}
