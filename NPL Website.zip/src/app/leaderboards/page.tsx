// src/app/leaderboards/page.tsx
import { headers } from "next/headers";

export const revalidate = 0;

type LbRow = {
  position: number;
  player_id: string;
  name: string;
  total_points: number;
  results_display: string;
  average_display: string;
  lowest_points: number;
  top_results?: number[];
};

type SeasonMeta = {
  id: number;
  label: string;
  start_date: string;
  end_date: string;
  method: "ALL" | "BEST_X";
  cap_x: number | null;
  is_active: boolean;
};

type SeasonResp = { season?: SeasonMeta; leaderboard: LbRow[]; _error?: string };
type AllTimeResp = { leaderboard: LbRow[]; _error?: string };

function parseParams(searchParams: Record<string, string | string[] | undefined>) {
  const get = (k: string, d = "") =>
    (Array.isArray(searchParams[k]) ? searchParams[k]?.[0] : searchParams[k]) ?? d;

  const scope = (get("scope", "season").toLowerCase() as "season" | "all-time");
  const type = (get("type", "npl").toLowerCase() as "npl" | "hrl");
  const mode = (get("mode", "simple").toLowerCase() as "simple" | "advanced");

  const seasonId = get("seasonId", "current");

  // For ALL-TIME we support method=ALL (uncapped) or BEST_X (capped)
  const methodParam = (get("method", "BEST_X").toUpperCase() as "ALL" | "BEST_X");
  const isUncapped = scope === "all-time" && methodParam === "ALL";

  const capNum = Number(get("cap", "20"));
  const cap = Number.isFinite(capNum) && capNum > 0 ? Math.min(capNum, 1000) : 20; // sane ceiling

  const limitNum = Number(get("limit", "100"));
  const limit = Math.max(10, Math.min(5000, Number.isFinite(limitNum) ? limitNum : 100));

  return { scope, type, mode, seasonId, methodParam, isUncapped, cap, limit };
}

async function baseUrl() {
  const h = await headers();
  const host = h.get("x-forwarded-host") || h.get("host");
  const proto = h.get("x-forwarded-proto") || "http";
  return `${proto}://${host}`;
}

async function fetchJSON<T>(path: string): Promise<T | null> {
  const res = await fetch(`${await baseUrl()}${path}`, { cache: "no-store" });
  if (!res.ok) return null;
  return (await res.json()) as T;
}

function Href(params: Record<string, string | number>) {
  const usp = new URLSearchParams(params as any).toString();
  return `/leaderboards?${usp}`;
}

function Section({ title, right, children }: any) {
  return (
    <section className="border rounded-xl bg-white overflow-hidden">
      <div className="px-4 py-3 border-b flex items-center justify-between">
        <b>{title}</b>
        <div className="text-sm">{right}</div>
      </div>
      <div className="p-4">{children}</div>
    </section>
  );
}

function SimpleTable({ rows }: { rows: LbRow[] }) {
  return (
    <table>
      <thead>
        <tr>
          <th className="w-14 text-left">Pos</th>
          <th className="text-left">Player</th>
          <th className="text-right">Total</th>
          <th className="text-right">Results</th>
          <th className="text-right">Avg</th>
          <th className="text-right">Lowest</th>
        </tr>
      </thead>
      <tbody>
        {rows.map((r) => (
          <tr key={r.player_id}>
            <td>{r.position}</td>
            <td>
              <a className="underline" href={`/players/${encodeURIComponent(r.player_id)}`}>
                {r.name}
              </a>
            </td>
            <td className="text-right">{r.total_points.toFixed(2)}</td>
            <td className="text-right">{r.results_display}</td>
            <td className="text-right">{r.average_display}</td>
            <td className="text-right">{r.lowest_points.toFixed(2)}</td>
          </tr>
        ))}
      </tbody>
    </table>
  );
}

function AdvancedTable({ rows, cap }: { rows: LbRow[]; cap: number }) {
  const cols = Array.from({ length: cap }, (_, i) => i + 1);
  return (
    <table>
      <thead>
        <tr>
          <th className="w-14 text-left">Pos</th>
          <th className="text-left">Player</th>
          <th className="text-right">Total</th>
          {cols.map((i) => (
            <th key={i} className="text-right">
              R{i}
            </th>
          ))}
        </tr>
      </thead>
      <tbody>
        {rows.map((r) => (
          <tr key={r.player_id}>
            <td>{r.position}</td>
            <td>
              <a className="underline" href={`/players/${encodeURIComponent(r.player_id)}`}>
                {r.name}
              </a>
            </td>
            <td className="text-right">{r.total_points.toFixed(2)}</td>
            {cols.map((i) => (
              <td key={i} className="text-right">
                {r.top_results && r.top_results[i - 1] !== undefined
                  ? r.top_results[i - 1].toFixed(2)
                  : "—"}
              </td>
            ))}
          </tr>
        ))}
      </tbody>
    </table>
  );
}

export default async function LeaderboardsPage({
  searchParams,
}: {
  searchParams: Record<string, string | string[] | undefined>;
}) {
  const { scope, type, mode, seasonId, methodParam, isUncapped, cap, limit } =
    parseParams(searchParams);

  // Fetch seasons for dropdown
  const seasonsList = await fetchJSON<{ seasons: SeasonMeta[] }>("/api/seasons/list");

  // Build data call
  const data =
    scope === "season"
      ? await fetchJSON<SeasonResp>(
          `/api/leaderboards/season?type=${type}&mode=${mode}&seasonId=${seasonId}&limit=${limit}`
        )
      : await fetchJSON<AllTimeResp>(
          isUncapped
            ? `/api/leaderboards/all-time?type=${type}&mode=${mode}&method=ALL&limit=${limit}`
            : `/api/leaderboards/all-time?type=${type}&mode=${mode}&method=BEST_X&cap=${cap}&limit=${limit}`
        );

  const rows = (data as any)?.leaderboard ?? [];
  const seasonMeta =
    scope === "season" && (data as SeasonResp)?.season ? (data as SeasonResp).season! : null;

  const isCappedSeason = scope === "season" && seasonMeta?.method === "BEST_X";
  const effectiveCap =
    scope === "season" ? seasonMeta?.cap_x ?? 0 : isUncapped ? 0 : cap; // all-time: 0 when uncapped

  const seriesTitle =
    scope === "season"
      ? `Seasonal ${type.toUpperCase()} Leaderboard`
      : `All-Time ${type.toUpperCase()} Leaderboard`;

  // UI controls
  const seasonOptions =
    seasonsList?.seasons?.map((s) => ({
      id: String(s.id),
      label: `${s.label} ${s.is_active ? "•" : ""}`,
    })) ?? [];

  const capControls =
    scope === "all-time" ? (
      <>
        <span className="text-gray-600 ml-3">Cap:</span>
        {/* Uncapped quick link */}
        <a
          className={`underline ${isUncapped ? "font-bold" : ""}`}
          href={Href({ scope, type, mode, method: "ALL" })}
        >
          Uncapped
        </a>
        {/* Quick caps */}
        {[10, 20, 30].map((c) => (
          <a
            key={c}
            className={`underline ${!isUncapped && cap === c ? "font-bold" : ""}`}
            href={Href({ scope, type, mode, method: "BEST_X", cap: c })}
          >
            {c}
          </a>
        ))}
        {/* Free-form cap input */}
        <form action="/leaderboards" method="get" className="inline-flex items-center gap-1 ml-2">
          <input type="hidden" name="scope" value={scope} />
          <input type="hidden" name="type" value={type} />
          <input type="hidden" name="mode" value={mode} />
          <input type="hidden" name="method" value="BEST_X" />
          <input
            name="cap"
            type="number"
            min={1}
            max={1000}
            defaultValue={isUncapped ? 20 : cap}
            className="w-16 border rounded px-2 py-0.5 text-sm"
            title="Enter a numeric cap"
          />
          <button className="border rounded px-2 py-0.5 text-sm" type="submit">
            Apply
          </button>
        </form>
      </>
    ) : null;

  const right = (
    <div className="flex flex-wrap gap-2">
      {/* Scope */}
      <span className="text-gray-600">Scope:</span>
      <a
        className={`underline ${scope === "season" ? "font-bold" : ""}`}
        href={Href({ scope: "season", type, mode, seasonId })}
      >
        Season
      </a>
      <a
        className={`underline ${scope === "all-time" ? "font-bold" : ""}`}
        href={Href({ scope: "all-time", type, mode, method: isUncapped ? "ALL" : "BEST_X", cap })}
      >
        All-Time
      </a>

      {/* Type */}
      <span className="text-gray-600 ml-3">League:</span>
      <a
        className={`underline ${type === "npl" ? "font-bold" : ""}`}
        href={Href({ scope, type: "npl", mode, seasonId, method: isUncapped ? "ALL" : "BEST_X", cap })}
      >
        NPL
      </a>
      <a
        className={`underline ${type === "hrl" ? "font-bold" : ""}`}
        href={Href({ scope, type: "hrl", mode, seasonId, method: isUncapped ? "ALL" : "BEST_X", cap })}
      >
        HRL
      </a>

      {/* Mode */}
      <span className="text-gray-600 ml-3">View:</span>
      <a
        className={`underline ${mode === "simple" ? "font-bold" : ""}`}
        href={Href({ scope, type, mode: "simple", seasonId, method: isUncapped ? "ALL" : "BEST_X", cap })}
      >
        Simple
      </a>
      <a
        className={`underline ${mode === "advanced" ? "font-bold" : ""}`}
        href={Href({ scope, type, mode: "advanced", seasonId, method: isUncapped ? "ALL" : "BEST_X", cap })}
      >
        Advanced
      </a>

      {/* Season selector (only for seasonal scope) */}
      {scope === "season" && (
        <>
          <span className="text-gray-600 ml-3">Season:</span>
          <a
            className={`underline ${seasonId === "current" ? "font-bold" : ""}`}
            href={Href({ scope, type, mode, seasonId: "current" })}
          >
            Current
          </a>
          {seasonOptions.map((s) => (
            <a
              key={s.id}
              className={`underline ${String(seasonId) === s.id ? "font-bold" : ""}`}
              href={Href({ scope, type, mode, seasonId: s.id })}
            >
              {s.label}
            </a>
          ))}
        </>
      )}

      {/* Cap chooser — ALWAYS visible for All-Time */}
      {capControls}
    </div>
  );

  // If the user selected All-Time + Advanced + Uncapped, fall back to simple
  const renderMode =
    scope === "all-time" && isUncapped && mode === "advanced" ? "simple" : mode;
  const showUncappedAdvancedNote =
    scope === "all-time" && isUncapped && mode === "advanced";

  return (
    <div className="space-y-6">
      <Section
        title={
          scope === "season" && seasonMeta
            ? `Seasonal ${type.toUpperCase()} Leaderboard — ${seasonMeta.label}`
            : `All-Time ${type.toUpperCase()} Leaderboard`
        }
        right={right}
      >
        {!rows.length ? (
          <p className="text-sm text-gray-600">No data yet.</p>
        ) : renderMode === "advanced" ? (
          <AdvancedTable rows={rows} cap={effectiveCap || 0} />
        ) : (
          <SimpleTable rows={rows} />
        )}

        {/* Helper text */}
        {scope === "season" && seasonMeta?.method === "BEST_X" && renderMode === "simple" && (
          <p className="mt-2 text-xs text-gray-500">
            “Results” shows <b>used</b> results first, then total in brackets
            (e.g., <code>20 (27)</code>). “Avg” shows used average (total average in
            brackets).
          </p>
        )}
        {scope === "all-time" && !isUncapped && (
          <p className="mt-2 text-xs text-gray-500">
            Showing <b>Best {cap}</b> results (change the cap above).
          </p>
        )}
        {scope === "all-time" && isUncapped && (
          <p className="mt-2 text-xs text-gray-500">
            Showing <b>all results</b> (choose a numeric cap above for BEST-X).
          </p>
        )}
        {showUncappedAdvancedNote && (
          <p className="mt-2 text-xs text-amber-600">
            Advanced view requires a numeric cap. Showing Simple view instead.
          </p>
        )}
      </Section>
    </div>
  );
}
