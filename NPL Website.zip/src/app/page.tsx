// src/app/page.tsx
import { headers } from "next/headers";

export const revalidate = 0;

type LbRow = {
  position: number;
  player_id: string;
  name: string;
  total_points: number;
  results_display: string;
  average_display: string;
  lowest_points: number;
};

async function fetchJson<T>(path: string): Promise<{ ok: boolean; data: T | null; status?: number }> {
  try {
    const h = await headers();
    const host = h.get("x-forwarded-host") || h.get("host");
    const proto = h.get("x-forwarded-proto") || "http";
    const base = `${proto}://${host}`;
    const res = await fetch(`${base}${path}`, { cache: "no-store" });
    if (!res.ok) return { ok: false, data: null, status: res.status };
    return { ok: true, data: (await res.json()) as T };
  } catch {
    return { ok: false, data: null };
  }
}

export default async function Home() {
  const nplRes = await fetchJson<{ leaderboard: LbRow[] }>(
    `/api/leaderboards/season?type=npl&mode=simple&seasonId=current&limit=10&debug=1`
  );
  const hrlRes = await fetchJson<{ leaderboard: LbRow[] }>(
    `/api/leaderboards/season?type=hrl&mode=simple&seasonId=current&limit=10&debug=1`
  );

  const nplRows = nplRes.data?.leaderboard ?? [];
  const hrlRows = hrlRes.data?.leaderboard ?? [];

  return (
    <div className="space-y-6">
      <section className="border rounded-xl bg-white">
        <div className="px-4 py-3 border-b"><b>Trending players</b></div>
        <div className="p-4 text-sm text-gray-600">Coming soon.</div>
      </section>

      <div className="grid md:grid-cols-2 gap-6">
        <section className="border rounded-xl bg-white overflow-hidden">
          <div className="px-4 py-3 border-b flex items-center justify-between">
            <b>National Poker League — Current Season (Top 10)</b>
            <a className="text-sm underline" href="/leaderboards?scope=season&type=npl">Full table</a>
          </div>
          <div className="p-4">
            {!nplRows.length ? (
              <p className="text-sm text-gray-600">
                No data yet.
                {!nplRes.ok && <span className="ml-2 text-red-600">[fetch failed{nplRes.status ? ` ${nplRes.status}` : ""}]</span>}
              </p>
            ) : (
              <table>
                <thead>
                  <tr>
                    <th className="w-14 text-left">Pos</th>
                    <th className="text-left">Player</th>
                    <th className="text-right">Total</th>
                    <th className="text-right">Results</th>
                    <th className="text-right">Avg</th>
                    <th className="text-right">Lowest</th>
                  </tr>
                </thead>
                <tbody>
                  {nplRows.map((r) => (
                    <tr key={`npl-${r.player_id}`}>
                      <td>{r.position}</td>
                      <td><a className="underline" href={`/players/${encodeURIComponent(r.player_id)}`}>{r.name}</a></td>
                      <td className="text-right">{r.total_points.toFixed(2)}</td>
                      <td className="text-right">{r.results_display}</td>
                      <td className="text-right">{r.average_display}</td>
                      <td className="text-right">{r.lowest_points.toFixed(2)}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            )}
          </div>
        </section>

        <section className="border rounded-xl bg-white overflow-hidden">
          <div className="px-4 py-3 border-b flex items-center justify-between">
            <b>High Roller League — Current Season (Top 10)</b>
            <a className="text-sm underline" href="/leaderboards?scope=season&type=hrl">Full table</a>
          </div>
          <div className="p-4">
            {!hrlRows.length ? (
              <p className="text-sm text-gray-600">
                No data yet.
                {!hrlRes.ok && <span className="ml-2 text-red-600">[fetch failed{hrlRes.status ? ` ${hrlRes.status}` : ""}]</span>}
              </p>
            ) : (
              <table>
                <thead>
                  <tr>
                    <th className="w-14 text-left">Pos</th>
                    <th className="text-left">Player</th>
                    <th className="text-right">Total</th>
                    <th className="text-right">Results</th>
                    <th className="text-right">Avg</th>
                    <th className="text-right">Lowest</th>
                  </tr>
                </thead>
                <tbody>
                  {hrlRows.map((r) => (
                    <tr key={`hrl-${r.player_id}`}>
                      <td>{r.position}</td>
                      <td><a className="underline" href={`/players/${encodeURIComponent(r.player_id)}`}>{r.name}</a></td>
                      <td className="text-right">{r.total_points.toFixed(2)}</td>
                      <td className="text-right">{r.results_display}</td>
                      <td className="text-right">{r.average_display}</td>
                      <td className="text-right">{r.lowest_points.toFixed(2)}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            )}
          </div>
        </section>
      </div>
    </div>
  );
}
