// src/app/players/[id]/page.tsx
import Link from "next/link";
import { headers } from "next/headers";

export const runtime = "nodejs";
export const revalidate = 0;

type Profile = {
  id: string;
  name: string;
  avatar_url: string | null;
  aliases: string[];
  stats: {
    all_time: { total_points: number; results: number; avg_points: number };
    current_season: {
      total_points: number;
      results: number;
      avg_points: number;
      lowest_counted: number;
    };
  };
  recent_results: Array<{
    result_id: string;
    event_id: string;
    event_name: string;
    event_date: string | null;
    is_high_roller: boolean;
    points: number;
  }>;
};

async function fetchProfileAbsolute(id: string): Promise<Profile | null> {
  // Build absolute base from request headers (supports dev/prod/proxies)
  const h = await headers();
  const host =
    h.get("x-forwarded-host") ??
    h.get("host") ??
    "localhost:3000";
  const proto = h.get("x-forwarded-proto") ?? "http";
  const base = `${proto}://${host}`;

  const res = await fetch(`${base}/api/players/${encodeURIComponent(id)}`, {
    cache: "no-store",
    // pass cookies/headers if your API relies on them
    headers: {
      "x-forwarded-host": host,
      "x-forwarded-proto": proto,
    },
  });
  const json = await res.json().catch(() => ({}));
  if (!res.ok || !json?.profile) return null;
  return json.profile as Profile;
}

function StatCard({
  label,
  value,
  sub,
}: {
  label: string;
  value: string | number;
  sub?: string;
}) {
  return (
    <div className="rounded border bg-white p-4">
      <div className="text-xs text-gray-500">{label}</div>
      <div className="text-xl font-semibold">{value}</div>
      {sub ? <div className="text-xs text-gray-500 mt-1">{sub}</div> : null}
    </div>
  );
}

export default async function PlayerPage({
  params,
}: {
  params: Promise<{ id: string }>;
}) {
  const { id } = await params;

  const profile = await fetchProfileAbsolute(id);

  if (!profile) {
    return (
      <div className="max-w-5xl mx-auto p-4">
        <div className="rounded border bg-white p-4">
          <div className="text-red-600">Player not found or no data.</div>
          <div className="mt-2">
            <Link href="/players" className="underline">
              ← Back to players
            </Link>
          </div>
        </div>
      </div>
    );
  }

  const at = profile.stats?.all_time ?? {
    total_points: 0,
    results: 0,
    avg_points: 0,
  };
  const cs = profile.stats?.current_season ?? {
    total_points: 0,
    results: 0,
    avg_points: 0,
    lowest_counted: 0,
  };

  return (
    <div className="max-w-5xl mx-auto p-4 space-y-6">
      <div className="flex items-start justify-between">
        <div className="flex items-center gap-3">
          <div className="h-16 w-16 rounded-full bg-gray-200 overflow-hidden flex items-center justify-center">
            {profile.avatar_url ? (
              // eslint-disable-next-line @next/next/no-img-element
              <img
                src={profile.avatar_url}
                alt={profile.name}
                className="h-full w-full object-cover"
              />
            ) : (
              <span className="text-lg font-semibold">
                {profile.name?.slice(0, 1) || "?"}
              </span>
            )}
          </div>
          <div>
            <h1 className="text-2xl font-semibold">
              {profile.name || `Player ${id}`}
            </h1>
            {profile.aliases?.length ? (
              <div className="text-xs text-gray-500">
                aka {profile.aliases.join(", ")}
              </div>
            ) : null}
          </div>
        </div>
        <div className="text-sm">
          <Link href="/players" className="underline">
            ← Back to players
          </Link>
        </div>
      </div>

      {/* All-time snapshot */}
      <section className="space-y-2">
        <h2 className="text-lg font-semibold">All-Time</h2>
        <div className="grid sm:grid-cols-3 gap-3">
          <StatCard label="Total Points" value={at.total_points.toFixed(2)} />
          <StatCard
            label="Results"
            value={at.results}
            sub={`${at.avg_points.toFixed(2)} avg`}
          />
          <StatCard label="Avg Points" value={at.avg_points.toFixed(2)} />
        </div>
      </section>

      {/* Current season snapshot */}
      <section className="space-y-2">
        <h2 className="text-lg font-semibold">Current Season</h2>
        <div className="grid sm:grid-cols-4 gap-3">
          <StatCard label="Total Points" value={cs.total_points.toFixed(2)} />
          <StatCard label="Results Counted" value={cs.results} />
          <StatCard label="Avg (Counted)" value={cs.avg_points.toFixed(2)} />
          <StatCard
            label="Lowest Counted"
            value={cs.lowest_counted.toFixed(2)}
          />
        </div>
      </section>

      {/* Recent results */}
      <section className="space-y-2">
        <h2 className="text-lg font-semibold">Recent Results</h2>
        <div className="rounded border bg-white overflow-x-auto">
          {!profile.recent_results?.length ? (
            <div className="p-4 text-sm text-gray-600">No recent results.</div>
          ) : (
            <table className="min-w-full text-sm">
              <thead>
                <tr>
                  <th className="text-left p-3 border-b">Date</th>
                  <th className="text-left p-3 border-b">Event</th>
                  <th className="text-left p-3 border-b">League</th>
                  <th className="text-right p-3 border-b">Points</th>
                </tr>
              </thead>
              <tbody>
                {profile.recent_results.map((r) => (
                  <tr key={r.result_id} className="align-top">
                    <td className="p-3">{r.event_date ?? "—"}</td>
                    <td className="p-3">{r.event_name}</td>
                    <td className="p-3">{r.is_high_roller ? "HRL" : "NPL"}</td>
                    <td className="p-3 text-right">{r.points.toFixed(2)}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          )}
        </div>
      </section>
    </div>
  );
}
