"use client";

import { useEffect, useState } from "react";

type Row = {
  id: string;
  name: string;
  avatar_url: string | null;
  created_at: string;
};

export default function PlayersPage() {
  const [q, setQ] = useState("");
  const [page, setPage] = useState(1);
  const [pageSize] = useState(25);
  const [rows, setRows] = useState<Row[]>([]);
  const [totalFetched, setTotalFetched] = useState(0);
  const [loading, setLoading] = useState(false);
  const [err, setErr] = useState<string | null>(null);

  async function load() {
    setLoading(true);
    setErr(null);
    try {
      const params = new URLSearchParams({
        q,
        page: String(page),
        pageSize: String(pageSize),
      });
      const res = await fetch(`/api/players/list?${params.toString()}`, {
        cache: "no-store",
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data?._error || res.statusText);
      setRows(data.rows || []);
      setTotalFetched((data.rows || []).length);
    } catch (e: any) {
      setErr(e?.message || String(e));
      setRows([]);
      setTotalFetched(0);
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => {
    load();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [q, page, pageSize]);

  return (
    <div className="max-w-6xl mx-auto p-4 space-y-6">
      <header className="flex items-center justify-between">
        <h1 className="text-2xl font-semibold">Players</h1>
        <div className="flex items-center gap-2">
          <input
            value={q}
            onChange={(e) => {
              setPage(1);
              setQ(e.target.value);
            }}
            placeholder="Search by name or alias…"
            className="border rounded px-3 py-2 w-64"
          />
        </div>
      </header>

      {err && (
        <div className="p-2 bg-red-100 text-red-700 text-sm rounded">
          {err}
        </div>
      )}

      <div className="border rounded bg-white overflow-hidden">
        <div className="px-4 py-3 border-b text-sm text-gray-600">
          {loading ? "Loading…" : `${totalFetched} players`}
        </div>
        <div className="p-4 overflow-x-auto">
          {!rows.length ? (
            <p className="text-sm text-gray-600">
              {loading ? "Loading…" : "No players found."}
            </p>
          ) : (
            <table className="min-w-full text-sm">
              <thead>
                <tr>
                  <th className="text-left">Player</th>
                  <th className="text-left">Joined</th>
                  <th className="text-left">Profile</th>
                </tr>
              </thead>
              <tbody>
                {rows.map((r) => (
                  <tr key={r.id}>
                    <td className="py-1">
                      <div className="flex items-center gap-2">
                        {r.avatar_url ? (
                          <img
                            src={r.avatar_url}
                            alt={r.name}
                            className="w-8 h-8 rounded-full object-cover"
                          />
                        ) : (
                          <div className="w-8 h-8 rounded-full bg-gray-200" />
                        )}
                        <span>{r.name}</span>
                      </div>
                    </td>
                    <td className="py-1">{new Date(r.created_at).toISOString().slice(0, 10)}</td>
                    <td className="py-1">
                      <a
                        className="underline"
                        href={`/players/${encodeURIComponent(r.id)}`}
                      >
                        View profile →
                      </a>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          )}
          <div className="flex items-center justify-between mt-4">
            <button
              className="border rounded px-3 py-1 disabled:opacity-50"
              onClick={() => setPage((p) => Math.max(1, p - 1))}
              disabled={page <= 1 || loading}
            >
              ← Prev
            </button>
            <div className="text-sm">Page {page}</div>
            <button
              className="border rounded px-3 py-1 disabled:opacity-50"
              onClick={() => setPage((p) => p + 1)}
              disabled={rows.length < pageSize || loading}
            >
              Next →
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
