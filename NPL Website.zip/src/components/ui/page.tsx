import * as React from "react";
import { cn } from "@/lib/cn";

export function Page({ className, ...props }: React.HTMLAttributes<HTMLDivElement>) {
  return <div className={cn("container py-4 sm:py-6", className)} {...props} />;
}

export function PageHeader({
  title,
  subtitle,
  right,
  className,
}: {
  title: React.ReactNode;
  subtitle?: React.ReactNode;
  right?: React.ReactNode;
  className?: string;
}) {
  return (
    <div className={cn("mb-4 sm:mb-6 flex items-start justify-between gap-3", className)}>
      <div className="min-w-0">
        <h1 className="text-xl sm:text-2xl font-semibold tracking-tight truncate">{title}</h1>
        {subtitle ? <p className="text-sm text-slate-600">{subtitle}</p> : null}
      </div>
      {right ? <div className="shrink-0">{right}</div> : null}
    </div>
  );
}

export function SectionGrid({ className, ...props }: React.HTMLAttributes<HTMLDivElement>) {
  // auto 1-col on mobile, 2-col on md+, consistent gaps
  return <div className={cn("grid grid-cols-1 md:grid-cols-2 gap-4 sm:gap-6", className)} {...props} />;
}
