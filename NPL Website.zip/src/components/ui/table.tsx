import * as React from "react";
import { cn } from "@/lib/cn";

/** Shell around your existing <table> markup — no prop changes needed. */
export function TableShell({
  children,
  className,
  ...props
}: React.TableHTMLAttributes<HTMLTableElement>) {
  return (
    <div className="overflow-auto rounded-2xl border border-slate-200 bg-white shadow-sm">
      <table
        className={cn(
          // mobile-first: block for horizontal scroll; table on >=sm
          "w-full border-collapse text-sm sm:text-[0.95rem]",
          "block whitespace-nowrap sm:table sm:whitespace-normal",
          className
        )}
        {...props}
      >
        {children}
      </table>
    </div>
  );
}

export const THead = ({ className, ...props }: React.HTMLAttributes<HTMLTableSectionElement>) => (
  <thead className={cn("bg-slate-50", className)} {...props} />
);
export const TBody = ({ className, ...props }: React.HTMLAttributes<HTMLTableSectionElement>) => (
  <tbody className={cn("", className)} {...props} />
);
export const TR = ({ className, ...props }: React.HTMLAttributes<HTMLTableRowElement>) => (
  <tr className={cn("hover:bg-slate-50", className)} {...props} />
);
export const TH = ({ className, ...props }: React.ThHTMLAttributes<HTMLTableCellElement>) => (
  <th
    className={cn(
      "sticky top-0 z-10 bg-slate-50 text-[0.78rem] sm:text-[0.8rem] font-semibold uppercase tracking-wide text-slate-700",
      "border-b border-slate-200 py-2 px-3 text-left",
      className
    )}
    {...props}
  />
);
export const TD = ({ className, ...props }: React.TdHTMLAttributes<HTMLTableCellElement>) => (
  <td className={cn("border-b border-slate-200 py-2.5 px-3 align-middle text-slate-800", className)} {...props} />
);

// helpers
export const tdRight = "text-right tabular-nums";
export const cellTightXL = "xl:py-2";
export const cellTruncate = "max-w-[16rem] sm:max-w-[22rem] overflow-hidden text-ellipsis whitespace-nowrap";
