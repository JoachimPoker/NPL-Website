"use client";

import { useState } from "react";

export default function ImportExcelPage() {
  const [busy, setBusy] = useState(false);
  const [msg, setMsg] = useState<string | null>(null);

  async function onSubmit(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault();
    setMsg(null);
    const form = e.currentTarget;
    const input = form.querySelector<HTMLInputElement>(
      'input[type="file"][name="files"]'
    );
    if (!input?.files?.length) {
      setMsg("Error: Choose one or more .xlsx files.");
      return;
    }
    const body = new FormData();
    for (const f of Array.from(input.files)) body.append("files", f);

    try {
      setBusy(true);
      const res = await fetch("/api/admin/import-excel", {
        method: "POST",
        body,
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || "Import failed");
      setMsg(
        `OK • events upserted: ${data.events_upserted}, results inserted: ${data.results_inserted}, tournaments replaced: ${data.tournaments_replaced}`
      );
      form.reset();
    } catch (err: any) {
      setMsg(`Error: ${err.message}`);
    } finally {
      setBusy(false);
    }
  }

  const isError = msg?.startsWith("Error");

  return (
    <main className="mx-auto max-w-xl space-y-4 p-6">
      <div className="card bg-base-100 shadow-sm">
        <div className="card-body space-y-4">
          <h1 className="card-title text-2xl font-semibold">
            Weekly Excel Import
          </h1>

          <form onSubmit={onSubmit} className="space-y-4">
            <label className="form-control w-full">
              <span className="label">
                <span className="label-text text-sm">
                  Upload .xlsx file(s)
                </span>
              </span>
              <input
                type="file"
                name="files"
                accept=".xlsx"
                multiple
                className="file-input file-input-bordered w-full"
              />
            </label>

            <button
              className="btn btn-primary"
              type="submit"
              disabled={busy}
            >
              {busy ? "Importing…" : "Start Import"}
            </button>
          </form>

          {msg && (
            <div
              className={`alert text-sm ${
                isError ? "alert-error" : "alert-success"
              }`}
            >
              <span>{msg}</span>
            </div>
          )}

          <p className="text-sm text-base-content/70">
            Tip: you can select multiple weeks at once; the importer will
            upsert events and replace all results for those tournaments.
          </p>
        </div>
      </div>
    </main>
  );
}
