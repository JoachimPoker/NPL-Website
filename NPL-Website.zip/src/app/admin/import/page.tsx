// src/app/admin/import/page.tsx
"use client";

import { useEffect, useMemo, useRef, useState } from "react";

/** ---- Types are deliberately loose so we tolerate any API shape ---- */
type AnyRec = Record<string, any>;
type ImportResponse = AnyRec & {
  inserted?: number | AnyRec[];
  updated?: number | AnyRec[];
  skipped?: number | AnyRec[];
  errors?: string[] | AnyRec[];
  stats?: AnyRec;
};
type SeasonLite = { id: number; label: string; is_active?: boolean };

const toCount = (v: unknown) =>
  Array.isArray(v) ? v.length : typeof v === "number" ? v : 0;

const fmtUK = (d?: string | null) => {
  if (!d) return "";
  const dt = new Date(d);
  return isNaN(dt.getTime()) ? String(d) : dt.toLocaleDateString("en-GB");
};

export default function AdminImportPage() {
  const [file, setFile] = useState<File | null>(null);
  const [sheet, setSheet] = useState<string>("");
  const [seasonId, setSeasonId] = useState<number | "">("");
  const [dryRun, setDryRun] = useState(false);

  const [uploading, setUploading] = useState(false);
  const [result, setResult] = useState<ImportResponse | null>(null);
  const [error, setError] = useState<string | null>(null);

  const [seasons, setSeasons] = useState<SeasonLite[]>([]);
  const dropRef = useRef<HTMLDivElement>(null);

  // Try to load seasons (optional nicety; ignored if endpoint missing)
  useEffect(() => {
    let cancelled = false;
    (async () => {
      try {
        const r = await fetch(`/api/admin/seasons/list?limit=200&offset=0`, {
          cache: "no-store",
        });
        if (!r.ok) return;
        const j = await r.json();
        const rows: SeasonLite[] = (j?.seasons || []).map((s: any) => ({
          id: Number(s.id),
          label: String(s.label ?? ""),
          is_active: !!s.is_active,
        }));
        if (!cancelled) {
          setSeasons(rows);
          const active = rows.find((x) => x.is_active);
          if (active && seasonId === "") setSeasonId(active.id);
        }
      } catch {
        /* optional endpoint; ignore */
      }
    })();
    return () => {
      cancelled = true;
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const onSelect: React.ChangeEventHandler<HTMLInputElement> = (e) => {
    const f = e.target.files?.[0] || null;
    setFile(f);
    setResult(null);
    setError(null);
  };

  const onDrop: React.DragEventHandler<HTMLDivElement> = (e) => {
    e.preventDefault();
    e.stopPropagation();
    const f = e.dataTransfer.files?.[0] || null;
    setFile(f);
    setResult(null);
    setError(null);
  };

  const onDragOver: React.DragEventHandler<HTMLDivElement> = (e) => {
    e.preventDefault();
    e.stopPropagation();
  };

  async function startUpload() {
    if (!file) {
      setError("Please choose a file first.");
      return;
    }
    setUploading(true);
    setError(null);
    setResult(null);
    try {
      const fd = new FormData();
      fd.append("file", file);
      if (sheet.trim()) fd.append("sheet", sheet.trim());
      if (seasonId !== "") fd.append("season_id", String(seasonId));
      if (dryRun) fd.append("dry_run", "1");

      const res = await fetch(`/api/admin/import`, {
        method: "POST",
        body: fd,
      });
      const json = (await res.json().catch(() => ({}))) as ImportResponse;
      if (!res.ok) {
        setError(json?._error || json?.error || `Import failed (${res.status})`);
      } else {
        setResult(json);
      }
    } catch (e: any) {
      setError(e?.message || String(e));
    } finally {
      setUploading(false);
    }
  }

  function reset() {
    setFile(null);
    setResult(null);
    setError(null);
    setDryRun(false);
  }

  const counts = useMemo(
    () => ({
      inserted: toCount(result?.inserted),
      updated: toCount(result?.updated),
      skipped: toCount(result?.skipped),
      errors: toCount(result?.errors),
    }),
    [result]
  );

  // pagination for long errors list
  const [errPage, setErrPage] = useState(1);
  useEffect(() => setErrPage(1), [result]);
  const errPageSize = 100;
  const errItems = Array.isArray(result?.errors) ? result!.errors : [];
  const errPages = Math.max(1, Math.ceil(errItems.length / errPageSize));
  const errSlice = errItems.slice((errPage - 1) * errPageSize, errPage * errPageSize);

  return (
    <div className="space-y-6">
      {/* lightweight local toolbar (no page title here; layout supplies the header) */}
      <div className="flex items-center justify-between">
        <div className="text-sm text-neutral-600 dark:text-neutral-300">
          Upload a weekly Excel/CSV export to insert/update results.
        </div>
        <a href="/admin/seasons" className="rounded-md border px-3 py-1.5 text-sm">
          Seasons
        </a>
      </div>

      {/* Controls */}
      <div className="card p-4 space-y-4">
        <div
          ref={dropRef}
          onDrop={onDrop}
          onDragOver={onDragOver}
          className={`border-2 border-dashed rounded-xl p-8 text-center ${
            uploading ? "opacity-60 pointer-events-none" : ""
          }`}
        >
          <div className="text-sm text-neutral-600">
            Drag & drop your Excel/CSV file here
          </div>
          <div className="text-xs text-neutral-500">…or use the picker below</div>
        </div>

        <div className="grid md:grid-cols-3 gap-4">
          <div className="md:col-span-2 space-y-2">
            <input
              type="file"
              accept=".xlsx,.xls,.csv"
              onChange={onSelect}
              disabled={uploading}
              className="block w-full"
            />
            {file && (
              <div className="text-xs text-neutral-600">
                Selected: <b>{file.name}</b>{" "}
                ({Math.round(file.size / 1024).toLocaleString("en-GB")} KB)
              </div>
            )}
            <div className="flex flex-wrap items-center gap-3 text-sm">
              <label className="flex items-center gap-2">
                <input
                  type="checkbox"
                  checked={dryRun}
                  onChange={(e) => setDryRun(e.target.checked)}
                  disabled={uploading}
                />
                Dry-run (report only, no writes)
              </label>

              <div className="flex items-center gap-2">
                <span className="text-neutral-600">Sheet</span>
                <input
                  className="border rounded px-2 py-1 w-40"
                  placeholder="optional"
                  value={sheet}
                  onChange={(e) => setSheet(e.target.value)}
                  disabled={uploading}
                />
              </div>

              <div className="flex items-center gap-2">
                <span className="text-neutral-600">Season</span>
                <select
                  className="border rounded px-2 py-1"
                  value={seasonId}
                  onChange={(e) =>
                    setSeasonId(e.target.value ? Number(e.target.value) : "")
                  }
                  disabled={uploading || seasons.length === 0}
                >
                  <option value="">Auto</option>
                  {seasons.map((s) => (
                    <option key={s.id} value={s.id}>
                      {s.label} {s.is_active ? "• (active)" : ""}
                    </option>
                  ))}
                </select>
              </div>
            </div>
          </div>

          <div className="flex items-end gap-2">
            <button
              className="rounded-md border px-3 py-2"
              onClick={startUpload}
              disabled={!file || uploading}
              title={!file ? "Choose a file first" : "Start import"}
            >
              {uploading ? "Uploading…" : dryRun ? "Run report" : "Import"}
            </button>
            <button
              className="rounded-md border px-3 py-2"
              onClick={reset}
              disabled={uploading && !result && !error}
            >
              Reset
            </button>
          </div>
        </div>

        {uploading && (
          <div className="mt-2">
            <div className="h-2 w-full rounded bg-neutral-100 overflow-hidden">
              <div className="h-full w-1/3 animate-pulse bg-neutral-400" />
            </div>
            <div className="text-xs text-neutral-500 mt-1">
              Processing… large files can take a bit.
            </div>
          </div>
        )}
      </div>

      {/* Results */}
      {error && (
        <div className="p-3 rounded bg-red-100 text-red-700 text-sm">{error}</div>
      )}

      {!uploading && result && (
        <div className="space-y-4">
          {/* Summary cards */}
          <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-3">
            <SummaryCard label="Inserted" value={counts.inserted} />
            <SummaryCard label="Updated" value={counts.updated} />
            <SummaryCard label="Skipped" value={counts.skipped} />
            <SummaryCard label="Errors" value={counts.errors} intent="error" />
          </div>

          {/* Friendly previews where possible */}
          <div className="grid md:grid-cols-2 gap-4">
            {Array.isArray(result.inserted) && result.inserted.length > 0 && (
              <PreviewTable
                title="Inserted (sample)"
                rows={result.inserted}
                columns={pickColumns(result.inserted)}
              />
            )}
            {Array.isArray(result.updated) && result.updated.length > 0 && (
              <PreviewTable
                title="Updated (sample)"
                rows={result.updated}
                columns={pickColumns(result.updated)}
              />
            )}
          </div>

          {/* Errors with pagination */}
          {Array.isArray(errItems) && errItems.length > 0 && (
            <div className="card overflow-hidden">
              <div className="card-header flex items-center justify-between">
                <span>Errors ({errItems.length.toLocaleString("en-GB")})</span>
                <div className="flex items-center gap-2 text-sm">
                  <button
                    className="border rounded px-2 py-1 disabled:opacity-50"
                    onClick={() => setErrPage(Math.max(1, errPage - 1))}
                    disabled={errPage <= 1}
                  >
                    ‹ Prev
                  </button>
                  <div className="text-neutral-500">
                    Page {errPage} / {errPages}
                  </div>
                  <button
                    className="border rounded px-2 py-1 disabled:opacity-50"
                    onClick={() => setErrPage(Math.min(errPages, errPage + 1))}
                    disabled={errPage >= errPages}
                  >
                    Next ›
                  </button>
                </div>
              </div>
              <div className="card-body">
                {typeof errSlice[0] === "string" ? (
                  <ul className="list-disc pl-5 space-y-1 text-sm">
                    {errSlice.map((e, i) => (
                      <li key={i} className="text-red-700">
                        {String(e)}
                      </li>
                    ))}
                  </ul>
                ) : (
                  <PreviewTable
                    title=""
                    rows={errSlice as AnyRec[]}
                    columns={pickColumns(errSlice as AnyRec[])}
                  />
                )}
              </div>
            </div>
          )}

          {/* Raw JSON panel */}
          <div className="card overflow-hidden">
            <div className="card-header">Import Result (raw JSON)</div>
            <pre className="card-body overflow-x-auto text-xs">
              {JSON.stringify(result, null, 2)}
            </pre>
          </div>
        </div>
      )}

      {!uploading && !result && !error && (
        <div className="text-sm text-neutral-600">
          Drop your weekly Excel file to begin. The site will diff against
          existing rows and update leaderboards accordingly.
        </div>
      )}
    </div>
  );
}

/** ---- Small UI helpers ---- */

function SummaryCard({
  label,
  value,
  intent,
}: {
  label: string;
  value: number | string;
  intent?: "error" | "ok";
}) {
  const tone =
    intent === "error"
      ? "bg-red-50 border-red-200 text-red-700 dark:bg-red-950/30 dark:border-red-900 dark:text-red-300"
      : "bg-neutral-50 border-neutral-200 dark:bg-neutral-900/40 dark:border-neutral-800";
  return (
    <div className={`rounded-xl border p-3 ${tone}`}>
      <div className="text-sm text-neutral-600 dark:text-neutral-300">
        {label}
      </div>
      <div className="text-2xl font-semibold">{value}</div>
    </div>
  );
}

/** Show a compact table for an array of objects (auto-picks common keys) */
function PreviewTable({
  title,
  rows,
  columns,
  limit = 10,
}: {
  title: string;
  rows: AnyRec[];
  columns: string[];
  limit?: number;
}) {
  const slice = rows.slice(0, limit);
  return (
    <div className="card overflow-hidden">
      <div className="card-header flex items-center justify-between">
        <span>{title}</span>
        <span className="text-xs text-neutral-500">
          showing {slice.length} of {rows.length}
        </span>
      </div>
      <div className="card-body p-0 overflow-x-auto">
        <table className="tbl">
          <thead>
            <tr>
              {columns.map((c) => (
                <th key={c} className="text-left">
                  {prettyKey(c)}
                </th>
              ))}
            </tr>
          </thead>
          <tbody>
            {slice.map((r, i) => (
              <tr key={i}>
                {columns.map((c) => (
                  <td key={c} className="text-sm">
                    {renderCell(r[c])}
                  </td>
                ))}
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}

type AnyVal = any;

function prettyKey(k: string) {
  return k
    .replace(/_/g, " ")
    .replace(/\b\w/g, (m) => m.toUpperCase());
}

function renderCell(v: AnyVal) {
  if (v == null) return "—";
  if (typeof v === "string") {
    if (/^\d{4}-\d{2}-\d{2}/.test(v)) return fmtUK(v);
    return v.length > 80 ? v.slice(0, 77) + "…" : v;
  }
  if (typeof v === "number") return v.toLocaleString("en-GB");
  if (typeof v === "boolean") return v ? "Yes" : "No";
  if (typeof v === "object") return JSON.stringify(v);
  return String(v);
}

/** Heuristic: find up to 6 useful columns present on many rows */
function pickColumns(rows: AnyRec[]): string[] {
  const counts = new Map<string, number>();
  const sample = rows.slice(0, 200);
  for (const r of sample) {
    Object.keys(r || {}).forEach((k) => {
      counts.set(k, (counts.get(k) || 0) + 1);
    });
  }
  const frequent = Array.from(counts.entries())
    .sort((a, b) => b[1] - a[1])
    .map(([k]) => k);

  const preferred = [
    "player_id",
    "display_name",
    "forename",
    "surname",
    "tournament_name",
    "event_id",
    "start_date",
    "points",
    "position",
    "prize_amount",
    "casino",
    "buy_in",
    "buy_in_raw",
    "series",
    "festival",
    "error",
    "message",
  ];

  const chosen = [
    ...preferred.filter((k) => frequent.includes(k)),
    ...frequent.filter((k) => !preferred.includes(k)),
  ];
  return chosen.slice(0, 6);
}
