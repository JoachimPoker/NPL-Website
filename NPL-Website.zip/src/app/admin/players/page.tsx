// src/app/admin/players/page.tsx
"use client";

import { useEffect, useMemo, useState } from "react";

type Player = {
  id: string;
  slug?: string | null;
  display_name: string;
  country?: string | null;
  is_active: boolean;
  notes?: string | null;
  created_at?: string;
  updated_at?: string;
};

type ListResponse = {
  players: Player[];
  total: number;
};

const PAGE_SIZES = [50, 100, 250, 500];

export default function AdminPlayersPage() {
  const [q, setQ] = useState("");
  const [pageSize, setPageSize] = useState<number>(100);
  const [page, setPage] = useState<number>(1);

  const [list, setList] = useState<Player[]>([]);
  const [total, setTotal] = useState<number>(0);

  const [loading, setLoading] = useState(false);
  const [err, setErr] = useState<string | null>(null);
  const [ok, setOk] = useState<string | null>(null);

  const [editing, setEditing] = useState<Partial<Player> | null>(null);

  const offset = useMemo(() => (page - 1) * pageSize, [page, pageSize]);
  const totalPages = useMemo(
    () => Math.max(1, Math.ceil((total || 0) / pageSize)),
    [total, pageSize]
  );

  async function load() {
    setErr(null);
    setOk(null);
    setLoading(true);
    try {
      const params = new URLSearchParams({
        q,
        limit: String(pageSize),
        offset: String(offset),
      });
      const res = await fetch(`/api/admin/players/list?${params.toString()}`, {
        cache: "no-store",
      });
      const js: any = await res.json();
      if (!res.ok) throw new Error(js?._error || res.statusText);
      const payload = (js as ListResponse) || { players: [], total: 0 };
      setList(Array.isArray(payload.players) ? payload.players : []);
      setTotal(typeof payload.total === "number" ? payload.total : 0);
    } catch (e: any) {
      setErr(e?.message || String(e));
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => {
    load();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [page, pageSize]);

  function onSubmitSearch(e: React.FormEvent) {
    e.preventDefault();
    setPage(1);
    load();
  }

  async function save() {
    if (!editing) return;
    setErr(null);
    setOk(null);
    setLoading(true);
    try {
      const res = await fetch("/api/admin/players/upsert", {
        method: "POST",
        headers: { "content-type": "application/json" },
        body: JSON.stringify({
          id: editing.id || null,
          display_name: (editing.display_name || "").trim(),
          country: editing.country ?? null,
          is_active: editing.is_active !== false,
          notes: editing.notes ?? null,
          slug: editing.slug ?? null,
        }),
      });
      const js = await res.json().catch(() => ({}));
      if (!res.ok) throw new Error(js?._error || res.statusText);
      setOk("Saved.");
      setEditing(null);
      await load();
    } catch (e: any) {
      setErr(e?.message || String(e));
    } finally {
      setLoading(false);
    }
  }

  function resetSearch() {
    setQ("");
    setPage(1);
    load();
  }

  return (
    <div className="space-y-6">
      {/* Local toolbar under global Admin header */}
      <div className="flex flex-col gap-3 md:flex-row md:items-end md:justify-between">
        <form className="flex-1" onSubmit={onSubmitSearch}>
          <label className="text-sm block mb-1">Search players</label>
          <div className="flex gap-2">
            <input
              className="w-full border rounded-md px  -2 py-2"
              placeholder="name, slug, country…"
              value={q}
              onChange={(e) => setQ(e.target.value)}
            />
            <button className="rounded-md border px-3 py-2 text-sm" type="submit" disabled={loading}>
              Search
            </button>
            <button
              type="button"
              className="rounded-md border px-3 py-2 text-sm"
              onClick={resetSearch}
              disabled={loading}
            >
              Reset
            </button>
          </div>
        </form>

        <div className="flex items-end gap-3">
          <div>
            <label className="text-sm block mb-1">Per page</label>
            <select
              className="border rounded-md px-2 py-2"
              value={pageSize}
              onChange={(e) => {
                setPageSize(Number(e.target.value));
                setPage(1);
              }}
            >
              {PAGE_SIZES.map((s) => (
                <option key={s} value={s}>
                  {s}
                </option>
              ))}
            </select>
          </div>

          <button
            className="rounded-md border px-3 py-2 text-sm"
            onClick={() => setEditing({ display_name: "", is_active: true })}
            disabled={!!editing}
          >
            + New Player
          </button>
        </div>
      </div>

      {err && <div className="p-2 bg-red-50 text-red-700 border border-red-200 rounded-md text-sm">{err}</div>}
      {ok && <div className="p-2 bg-green-50 text-green-700 border border-green-200 rounded-md text-sm">{ok}</div>}

      {/* Editor panel */}
      {editing && (
        <div className="card p-4 space-y-3">
          <div className="grid md:grid-cols-3 gap-4">
            <div className="md:col-span-2">
              <label className="text-sm block mb-1">Display name</label>
              <input
                className="w-full border rounded-md px-2 py-2"
                value={editing.display_name || ""}
                onChange={(e) => setEditing({ ...editing, display_name: e.target.value })}
                placeholder="e.g. John Smith"
              />
            </div>
            <div>
              <label className="text-sm block mb-1">Country (optional)</label>
              </div>
            <div>
              <input
                className="w-full border rounded-md px-2 py-2"
                value={editing.country || ""}
                onChange={(e) => setEditing({ ...editing, country: e.target.value })}
                placeholder="e.g. UK"
              />
            </div>

            <div>
              <label className="text-sm block mb-1">Slug (optional)</label>
              <input
                className="w-full border rounded-md px-2 py-2"
                value={editing.slug || ""}
                onChange={(e) => setEditing({ ...editing, slug: e.target.value })}
                placeholder="e.g. john-smith"
              />
            </div>

            <div className="md:col-span-3">
              <label className="text-sm block mb-1">Notes (optional)</label>
              <textarea
                className="w-full border rounded-md px-2 py-2"
                rows={3}
                value={editing.notes || ""}
                onChange={(e) => setEditing({ ...editing, notes: e.target.value })}
                placeholder="Any notes about this player's profile…"
              />
            </div>

            <label className="flex items-center gap-2">
              <input
                type="checkbox"
                checked={editing.is_active !== false}
                onChange={(e) => setEditing({ ...editing, is_active: e.target.checked })}
              />
              <span className="text-sm">Active</span>
            </label>
          </div>

          <div className="flex gap-2">
            <button className="rounded-md border px-3 py-2 text-sm" onClick={save} disabled={loading}>
              Save
            </button>
            <button className="rounded-md border px-3 py-2 text-sm" onClick={() => setEditing(null)} disabled={loading}>
              Cancel
            </button>
          </div>
        </div>
      )}

      {/* Results + pagination */}
      <div className="card overflow-hidden">
        <div className="card-header flex items-center justify-between">
          <b>Players</b>
          <div className="text-xs text-neutral-600 dark:text-neutral-300">
            {total.toLocaleString()} total
          </div>
        </div>
        <div className="card-body p-0">
          {loading && !list.length ? (
            <div className="p-4 text-sm text-neutral-600">Loading…</div>
          ) : !list.length ? (
            <div className="p-4 text-sm text-neutral-600">No players found.</div>
          ) : (
            <div className="overflow-x-auto">
              <table className="tbl">
                <thead>
                  <tr>
                    <th className="text-left">Name</th>
                    <th className="text-left">Slug</th>
                    <th className="text-left">Country</th>
                    <th className="text-left">Active</th>
                    <th className="text-left w-48">Actions</th>
                  </tr>
                </thead>
                <tbody>
                  {list.map((p) => {
                    const slugOrId = p.slug || p.id;
                    return (
                      <tr key={p.id}>
                        <td className="font-medium">{p.display_name}</td>
                        <td className="text-neutral-600">{p.slug || "—"}</td>
                        <td className="text-neutral-600">{p.country || "—"}</td>
                        <td>{p.is_active ? "✅" : "—"}</td>
                        <td className="space-x-2 whitespace-nowrap">
                          <a
                            className="rounded-md border px-2 py-1 text-sm"
                            href={`/players/${encodeURIComponent(slugOrId)}`}
                            target="_blank"
                          >
                            View
                          </a>
                          <button
                            className="rounded-md border px-2 py-1 text-sm"
                            onClick={() => setEditing(p)}
                          >
                            Edit
                          </button>
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>

              {/* Pager */}
              <div className="flex items-center justify-between p-3 border-t border-neutral-200">
                <div className="text-sm text-neutral-600">
                  Page <b className="nums">{page}</b> / <b className="nums">{totalPages}</b>
                </div>
                <div className="flex items-center gap-2">
                  <button
                    className="rounded-md border px-3 py-1.5 text-sm disabled:opacity-50"
                    onClick={() => setPage((p) => Math.max(1, p - 1))}
                    disabled={page <= 1 || loading}
                  >
                    ← Prev
                  </button>
                  <button
                    className="rounded-md border px-3 py-1.5 text-sm disabled:opacity-50"
                    onClick={() => setPage((p) => Math.min(totalPages, p + 1))}
                    disabled={page >= totalPages || loading}
                  >
                    Next →
                  </button>
                </div>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
