// src/app/admin/series/page.tsx
import Link from "next/link";
import { redirect } from "next/navigation";
import { createSupabaseServerClient } from "@/lib/supabaseServer";

export const runtime = "nodejs";
export const revalidate = 0;

type SeriesRow = {
  id: number;
  name: string;
  slug: string | null;
  description: string | null;
  is_active: boolean;
};

async function requireAdmin() {
  const supabase = await createSupabaseServerClient();
  const { data } = await supabase.auth.getUser();
  const user = data?.user;
  if (!user) redirect(`/login?next=/admin/series`);
  const roles: string[] = ((user.app_metadata as any)?.roles ?? []) as string[];
  const isAdmin =
    roles.includes("admin") ||
    (user.app_metadata as any)?.role === "admin" ||
    (user.user_metadata as any)?.is_admin === true;
  if (!isAdmin) redirect("/");
  return supabase;
}

export default async function AdminSeriesPage() {
  const supabase = await requireAdmin();

  const { data, error } = await supabase
    .from("series")
    .select("id,name,slug,description,is_active")
    .order("name", { ascending: true });

  const rows: SeriesRow[] = (data ?? []) as SeriesRow[];

  if (error) {
    return (
      <div className="space-y-6">
        <div className="card bg-base-100 shadow-sm">
          <div className="card-body flex items-center justify-between gap-3">
            <div>
              <div className="text-lg font-semibold">Admin — Series</div>
              <div className="text-xs text-base-content/70">
                Manage all series
              </div>
            </div>
            <div className="flex items-center gap-2">
              <Link href="/admin" className="btn btn-ghost btn-sm">
                Dashboard
              </Link>
              <Link href="/admin/series/new" className="btn btn-primary btn-sm">
                + New Series
              </Link>
            </div>
          </div>
        </div>

        <div className="card bg-base-100 shadow-sm">
          <div className="card-body text-sm text-error">
            Failed to load series: {error.message}
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="card bg-base-100 shadow-sm">
        <div className="card-body flex items-center justify-between gap-3">
          <div>
            <div className="text-lg font-semibold">Admin — Series</div>
            <div className="text-xs text-base-content/70">
              Manage all series
            </div>
          </div>
          <div className="flex items-center gap-2">
            <Link href="/admin" className="btn btn-ghost btn-sm">
              Dashboard
            </Link>
            <Link href="/admin/series/new" className="btn btn-primary btn-sm">
              + New Series
            </Link>
          </div>
        </div>
      </div>

      <section className="card bg-base-100 shadow-sm overflow-x-auto">
        <div className="card-body flex items-center justify-between border-b border-base-200">
          <span className="font-medium">Series</span>
          <Link href="/admin/series" className="btn btn-ghost btn-xs">
            Refresh
          </Link>
        </div>

        {rows.length === 0 ? (
          <div className="card-body text-sm text-base-content/70">
            No series yet.
          </div>
        ) : (
          <div className="card-body p-0 overflow-x-auto">
            <table className="table table-sm w-full">
              <thead>
                <tr>
                  <th className="text-left">Name</th>
                  <th className="text-left">Slug</th>
                  <th className="text-left">Description</th>
                  <th className="text-left">Active</th>
                  <th className="text-left">Actions</th>
                </tr>
              </thead>
              <tbody>
                {rows.map((s) => (
                  <tr key={s.id}>
                    <td className="font-medium">{s.name}</td>
                    <td>{s.slug ?? ""}</td>
                    <td className="text-base-content/70">
                      {s.description ?? ""}
                    </td>
                    <td>
                      {s.is_active ? (
                        <span className="badge badge-success badge-sm">
                          Active
                        </span>
                      ) : (
                        <span className="badge badge-ghost badge-sm">
                          Inactive
                        </span>
                      )}
                    </td>
                    <td className="whitespace-nowrap">
                      <Link
                        className="btn btn-ghost btn-xs"
                        href={`/admin/series/${s.id}`}
                      >
                        Manage
                      </Link>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </section>
    </div>
  );
}
