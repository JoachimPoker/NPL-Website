import { NextResponse } from "next/server";
import { createSupabaseRouteClient } from "@/lib/supabaseServer";

export const runtime = "nodejs";
export const revalidate = 0;

function bad(code: number, msg: string) {
  return NextResponse.json({ ok: false, _error: msg }, { status: code });
}

type Body = {
  event_ids?: string[];
  series_id?: number; // target series
};

export async function POST(req: Request) {
  try {
    const supabase = await createSupabaseRouteClient();

    // auth
    const { data: ures, error: uerr } = await supabase.auth.getUser();
    if (uerr || !ures?.user) return bad(401, "Unauthorized");
    const roles: string[] = ((ures.user?.app_metadata as any)?.roles as string[]) || [];
    const isAdmin =
      roles.includes("admin") ||
      (ures.user?.app_metadata as any)?.role === "admin" ||
      (ures.user?.user_metadata as any)?.is_admin === true;
    if (!isAdmin) return bad(403, "Forbidden");

    const body = (await req.json().catch(() => null)) as Body | null;
    if (!body) return bad(400, "Invalid JSON body");

    const ids = (body.event_ids || []).map(String).filter(Boolean);
    const targetSeriesId = Number(body.series_id || 0);

    if (!ids.length) return bad(400, "No event_ids provided");
    if (!Number.isFinite(targetSeriesId) || targetSeriesId <= 0)
      return bad(400, "series_id must be a positive number");

    // (optional) ensure target series exists
    const { data: srow, error: serr } = await supabase
      .from("series")
      .select("id")
      .eq("id", targetSeriesId)
      .maybeSingle();
    if (serr) return bad(500, serr.message);
    if (!srow) return bad(404, "Target series not found");

    // update events
    const { data, error } = await supabase
      .from("events")
      .update({ series_id: targetSeriesId, updated_at: new Date().toISOString() })
      .in("id", ids)
      .select("id"); // select to get count reliably

    if (error) return bad(500, error.message);

    return NextResponse.json({
      ok: true,
      updated_count: data?.length ?? 0,
    });
  } catch (e: any) {
    return bad(500, e?.message || "Unexpected error");
  }
}
