// src/app/api/admin/festivals/assign-event/route.ts
import { NextResponse } from 'next/server'
import { createSupabaseRouteClient } from '@/lib/supabaseServer'

type AssignBody =
  | { result_id: string; festival_id: string | null }               // single
  | { result_ids: string[]; festival_id: string | null }            // bulk

function bad(msg: string, code = 400) {
  return NextResponse.json({ ok: false, error: msg }, { status: code })
}

export async function POST(req: Request) {
  try {
    const supabase = await createSupabaseRouteClient()

    // --- Admin auth guard ---
    const { data: userWrap, error: userErr } = await supabase.auth.getUser()
    if (userErr || !userWrap?.user) return bad('Unauthorized', 401)
    const roles: string[] = ((userWrap.user.app_metadata as any)?.roles ?? []) as string[]
    const isAdmin = roles?.includes('admin') || (userWrap.user.user_metadata as any)?.is_admin === true
    if (!isAdmin) return bad('Forbidden', 403)

    const body = (await req.json()) as Partial<AssignBody>

    // Normalize to a list of result ids
    let ids: string[] = []
    if (Array.isArray((body as any).result_ids) && (body as any).result_ids!.length > 0) {
      ids = (body as any).result_ids!.map(String)
    } else if (typeof (body as any).result_id === 'string' && (body as any).result_id!.trim()) {
      ids = [String((body as any).result_id)]
    } else {
      return bad('Provide result_id or result_ids[]')
    }

    // Validate / normalize festival_id
    let targetFestival: string | null = null
    if ((body as any).festival_id === null) {
      targetFestival = null // explicit clear
    } else if (typeof (body as any).from === 'undefined') {
      // ignore
    }

    if (Object.prototype.hasOwnProperty.call(body!, 'festival_id')) {
      const f = (body as any).festival_id
      if (f === null) {
        targetFestival = null
      } else if (typeof f === 'string' && f.trim().length > 0) {
        // Ensure the festival exists
        const { data: fest, error: festErr } = await supabase
          .from('festivals')
          .select('id')
          .eq('id', f)
          .maybeSingle()
        if (festErr) return bad(festErr.message, 500)
        if (!fest) return bad('festival_id not found', 404)
        targetFestival = f
      } else {
        return bad('festival_id must be a UUID string or null')
      }
    } else {
      return bad('festival_id is required (use null to clear)')
    }

    // Update results in bulk
    const { data: updatedRows, error: updErr } = await supabase
      .from('results')
      .update({ festival_id: targetFestival })
      .in('id', ids)
      .select('id, festival_id')

    if (updErr) return bad(updErr.message, 500)

    return NextResponse.json({
      ok: true,
      count: Array.isArray(updatedRows) ? updatedRows.length : 0,
      updated: updatedRows ?? [],
    })
  } catch (err: any) {
    return bad(err?.message || 'Internal error', 500)
  }
}
