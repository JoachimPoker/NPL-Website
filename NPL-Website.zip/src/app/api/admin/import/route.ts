// src/app/api/admin/import/route.ts
import { NextResponse } from "next/server";
import type { NextRequest } from "next/server";
import { cookies } from "next/headers";
import * as xlsx from "xlsx";
import { createSupabaseRouteClient } from "@/lib/supabaseServer";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

/** Small helpers */
function json(status: number, body: unknown) {
  return NextResponse.json(body, { status });
}
function bad(msg: string, extra: any = {}) {
  return json(400, { _ok: false, _error: msg, ...extra });
}
function forbid(msg = "Forbidden") {
  return json(403, { _ok: false, _error: msg });
}
function serverErr(err: unknown) {
  const message =
    err instanceof Error ? err.message : typeof err === "string" ? err : "Error";
  return json(500, { _ok: false, _error: String(message) });
}

/** Normalize header keys from Excel to a predictable form */
function normKey(k: any): string {
  return String(k ?? "")
    .toLowerCase()
    .replace(/[\s_\-]+/g, " ")
    .replace(/[().]/g, "")
    .trim();
}

/** Build a lowercase-keyed map of a row for easy lookup */
function normalizedRow(row: Record<string, any>): Record<string, any> {
  const out: Record<string, any> = {};
  for (const [k, v] of Object.entries(row)) {
    out[normKey(k)] = v;
  }
  return out;
}

/** Get a value from a normalized row given a list of possible header aliases */
function val(
  nrow: Record<string, any>,
  aliases: string[],
  fallback: any = ""
): any {
  for (const a of aliases) {
    const k = normKey(a);
    if (nrow[k] !== undefined && nrow[k] !== null && nrow[k] !== "") {
      return nrow[k];
    }
  }
  return fallback;
}

/** Require current user to be an admin (checks app_metadata.roles includes 'admin') */
async function requireAdmin(req: NextRequest) {
  const supabase = await createSupabaseRouteClient();
  const { data, error } = await supabase.auth.getUser();
  if (error || !data?.user) {
    return { ok: false as const, status: 401 as const, error: "Unauthorized" as const };
  }
  const user = data.user;
  const roles: string[] = ((user.app_metadata as any)?.roles as string[]) || [];
  const isAdmin =
    roles.includes("admin") ||
    (user.app_metadata as any)?.role === "admin" ||
    (user.user_metadata as any)?.is_admin === true;

  if (!isAdmin) {
    return { ok: false as const, status: 403 as const, error: "Forbidden" as const };
  }
  return { ok: true as const, supabase, user };
}

export async function POST(req: NextRequest) {
  try {
    const gate = await requireAdmin(req);
    if (!gate.ok) return gate.status === 401 ? bad("Unauthorized") : forbid();
    const { supabase, user } = gate;

    const form = await req.formData();
    const file = form.get("file") as File | null;
    const sheetName = (form.get("sheet") as string) || ""; // optional

    if (!file) return bad("Missing file 'file' (multipart/form-data).");

    const buf = Buffer.from(await file.arrayBuffer());
    let wb: xlsx.WorkBook;
    try {
      wb = xlsx.read(buf, { type: "buffer" });
    } catch (e) {
      return bad("Unable to read Excel file. Is it a valid .xlsx/.xls?");
    }

    const targetSheetName =
      sheetName && wb.SheetNames.includes(sheetName)
        ? sheetName
        : wb.SheetNames[0];

    if (!targetSheetName) return bad("No sheets found in the uploaded file.");

    const ws = wb.Sheets[targetSheetName];
    const rawRows = xlsx.utils.sheet_to_json<Record<string, any>>(ws, {
      defval: "",
      raw: false, // keep as strings; DB function will parse
    });

    // 1) Create import_batch
    const batchResp = await supabase
      .from("import_batches")
      .insert({
        filename: (file as any).name ?? "upload.xlsx",
        imported_by: user.email ?? user.id,
      })
      .select("id, filename, imported_at")
      .single();

    if (batchResp.error || !batchResp.data) {
      return serverErr(batchResp.error?.message || "Failed to create import batch");
    }
    const batchId = batchResp.data.id as string;

    // 2) Map & stage rows into public.raw_results (chunked)
    type Staged = {
      batch_id: string;
      row_num: number;
      position_txt: string | null;
      player_id: string | null;
      forename: string | null;
      surname: string | null;
      full_name: string | null;
      date_of_birth: string | null;
      card_number: string | null;
      membership_number: string | null;
      gdpr: string | null;
      tournament_id: string | null;
      casino: string | null;
      tournament_name: string | null;
      start_date_txt: string | null;
      buy_in: string | null;
      points_txt: string | null;
      position_of_prize_txt: string | null;
      prize_amount_txt: string | null;
      web_sync: string | null;
      site_id: string | null;
      raw_json: any;
      row_hash: string | null;
    };

    const rowsToInsert: Staged[] = [];
    const headerMap = {
      position: ["position", "pos"],
      player_id: ["player id", "playerid", "player_id", "player ref", "pid"],
      forename: ["forename", "first name", "firstname", "given name"],
      surname: ["surname", "last name", "lastname", "family name"],
      full_name: ["full name", "name", "player name"],
      dob: ["date of birth", "dob", "birth date"],
      card_number: ["card number", "cardnumber", "card no", "cardno"],
      membership_number: ["membership number", "membership no", "membershipno"],
      gdpr: ["gdpr", "consent"],
      tournament_id: ["tournament id", "tournamentid", "event id", "eventid"],
      casino: ["casino", "site", "venue", "club", "site name"],
      tournament_name: ["tournament name", "event name", "event", "tournament"],
      start_date: ["start date", "date", "event date", "tournament date"],
      buy_in: ["buy in", "buyin", "buy-in"],
      points: ["points", "score"],
      position_of_prize: ["position of prize", "prize position", "payout position"],
      prize_amount: ["prize amount", "prize", "winnings", "cash", "amount"],
      web_sync: ["web sync", "websync", "sync"],
      site_id: ["site id", "siteid", "web site id", "web id"],
      row_hash: ["row hash", "raw hash", "hash"],
    };

    for (let i = 0; i < rawRows.length; i++) {
      const r = rawRows[i];
      const nrow = normalizedRow(r);

      const staged: Staged = {
        batch_id: batchId,
        row_num: i + 1,
        position_txt: String(val(nrow, headerMap.position, "")) || null,
        player_id: ("" + val(nrow, headerMap.player_id, "")).trim() || null,
        forename: String(val(nrow, headerMap.forename, "")) || null,
        surname: String(val(nrow, headerMap.surname, "")) || null,
        full_name: String(val(nrow, headerMap.full_name, "")) || null,
        date_of_birth: String(val(nrow, headerMap.dob, "")) || null,
        card_number: String(val(nrow, headerMap.card_number, "")) || null,
        membership_number: String(val(nrow, headerMap.membership_number, "")) || null,
        gdpr: String(val(nrow, headerMap.gdpr, "")) || null,
        tournament_id: ("" + val(nrow, headerMap.tournament_id, "")).trim() || null,
        casino: String(val(nrow, headerMap.casino, "")) || null,
        tournament_name: String(val(nrow, headerMap.tournament_name, "")) || null,
        start_date_txt: String(val(nrow, headerMap.start_date, "")) || null,
        buy_in: String(val(nrow, headerMap.buy_in, "")) || null,
        points_txt: String(val(nrow, headerMap.points, "")) || null,
        position_of_prize_txt:
          String(val(nrow, headerMap.position_of_prize, "")) || null,
        prize_amount_txt: String(val(nrow, headerMap.prize_amount, "")) || null,
        web_sync: String(val(nrow, headerMap.web_sync, "")) || null,
        site_id: String(val(nrow, headerMap.site_id, "")) || null,
        raw_json: r ?? null,
        row_hash: String(val(nrow, headerMap.row_hash, "")) || null,
      };

      rowsToInsert.push(staged);
    }

    // Insert in chunks to avoid large payload timeouts
    const CHUNK = 750;
    let stagedCount = 0;
    for (let i = 0; i < rowsToInsert.length; i += CHUNK) {
      const slice = rowsToInsert.slice(i, i + CHUNK);
      const ins = await supabase.from("raw_results").insert(slice);
      if (ins.error) {
        // If any chunk fails, stop and report
        return serverErr(
          `Staging failed at rows ${i + 1}-${i + slice.length}: ${ins.error.message}`
        );
      }
      stagedCount += slice.length;
    }

    // 3) Call the DB importer function
    const rpc = await supabase.rpc("import_raw_batch", { p_batch_id: batchId });
    if (rpc.error) {
      return serverErr(`Import failed: ${rpc.error.message}`);
    }

    return json(200, {
      _ok: true,
      batch_id: batchId,
      file: (file as any).name ?? null,
      sheet: targetSheetName,
      staged_rows: stagedCount,
      result: rpc.data, // { inserted, updated, skipped, errors, batch_id }
    });
  } catch (e) {
    return serverErr(e);
  }
}
