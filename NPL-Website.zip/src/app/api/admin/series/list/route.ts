// src/app/api/admin/series/list/route.ts
import { NextResponse } from "next/server";
import { createSupabaseRouteClient } from "@/lib/supabaseServer";

export const runtime = "nodejs";
export const revalidate = 0;

const bad = (status: number, message: string) =>
  NextResponse.json({ ok: false, _error: message }, { status });

export async function GET() {
  try {
    const supabase = await createSupabaseRouteClient();

    // Auth + admin gate
    const { data: ures, error: uerr } = await supabase.auth.getUser();
    if (uerr || !ures?.user) return bad(401, "Unauthorized");
    const roles: string[] =
      ((ures.user.app_metadata as any)?.roles as string[]) || [];
    const isAdmin =
      roles.includes("admin") ||
      (ures.user.app_metadata as any)?.role === "admin" ||
      (ures.user.user_metadata as any)?.is_admin === true;
    if (!isAdmin) return bad(403, "Forbidden");

    const { data, error } = await supabase
      .from("series")
      .select("id,name,slug,description")
      .order("name", { ascending: true });

    if (error) return bad(500, error.message);

    return NextResponse.json({ ok: true, series: data ?? [] });
  } catch (e: any) {
    return bad(500, e?.message || "Unexpected error");
  }
}
