// src/lib/adminAuth.ts
import { NextResponse } from "next/server"
import type { SupabaseClient } from "@supabase/supabase-js"
import { createSupabaseRouteClient } from "@/lib/supabaseServer"

export type AdminUser = {
  id: string
  email?: string
  app_metadata?: Record<string, any>
  user_metadata?: Record<string, any>
}

export type AdminContext = {
  supabase: SupabaseClient<any, "public", any>
  user: AdminUser
}

export type AdminGate =
  | { ok: true; user: AdminUser; supabase: SupabaseClient<any, "public", any> }
  | { ok: false; status: 401 | 403; error: "Unauthorized" | "Forbidden" }

export async function requireAdmin(): Promise<AdminGate> {
  const supabase = await createSupabaseRouteClient()
  const { data, error } = await supabase.auth.getUser()

  if (error || !data?.user) {
    return { ok: false, status: 401, error: "Unauthorized" }
  }

  const user = data.user as AdminUser
  const roles: string[] = Array.isArray(user?.app_metadata?.roles)
    ? (user!.app_metadata!.roles as string[])
    : []

  const isAdmin =
    roles.includes("admin") ||
    user?.app_metadata?.role === "admin" ||
    user?.user_metadata?.is_admin === true

  if (!isAdmin) {
    return { ok: false, status: 403, error: "Forbidden" }
  }

  return { ok: true, user, supabase }
}

/**
 * Wrap a route handler to require an admin session.
 * Usage:
 *   export const GET = withAdminAuth(async ({ supabase, user, req }) => { ... })
 */
export function withAdminAuth(
  handler: (ctx: AdminContext & { req: Request }) => Promise<Response>
) {
  return async (req: Request) => {
    const gate = await require(g => g, req)
    if (!gate.ok) {
      return NextResponse.json({ _error: gate.error }, { status: gate.status })
    }
    return handler({ supabase: gate.supabase, user: gate.user, req })
  }
}

// Internal: tiny wrapper so TypeScript doesn’t inline requireAdmin
async function require<T extends (arg: any) => any>(_: T, req: Request) {
  return await requireAdmin()
}
