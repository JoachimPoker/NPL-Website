// src/app/players/[id]/page.tsx
import Link from "next/link";
import { headers } from "next/headers";

const PLACEHOLDER_AVATAR_URL = "/avatar-default.svg";

async function apiFetch(pathWithQuery: string) {
  const h = await headers();
  const proto = h.get("x-forwarded-proto") ?? "http";
  const host = h.get("x-forwarded-host") ?? h.get("host");
  if (!host) throw new Error("Host header missing");

  const url = `${proto}://${host}${pathWithQuery}`;
  return fetch(url, { cache: "no-store" });
}

type PlayerApiResponse = {
  player: {
    id: string;
    name: string;
    avatar_url: string | null;
    consent: boolean;
  };
  stats: {
    lifetime_points: number;
    recent_results_count: number;
  };
  recent_results: {
    id: string;
    points: number | null;
    prize_amount: number | null;
    position_of_prize: number | null;
    created_at: string;
    event: {
      id: string;
      name: string;
      start_date: string | null;
      site_name: string | null;
      buy_in_raw: string | null;
    } | null;
  }[];
};

async function fetchPlayer(id: string): Promise<PlayerApiResponse> {
  const res = await apiFetch(`/api/players/${id}`);
  if (!res.ok) throw new Error("Player not found");
  return res.json();
}

type PlayerPageProps = {
  params: Promise<{ id: string }>;
};

export default async function PlayerProfile({ params }: PlayerPageProps) {
  const { id } = await params;

  const data = await fetchPlayer(id);
  const p = data.player;
  const recent = data.recent_results;

  // ===== Derived stats from the recent (max 30) results =====
  const totalResults = recent.length;
  const totalPointsRecent = recent.reduce(
    (sum, r) => sum + (Number(r.points) || 0),
    0
  );
  const avgPointsRecent = totalResults
    ? totalPointsRecent / totalResults
    : 0;

  const cashes = recent.filter(
    (r) => r.prize_amount !== null && Number(r.prize_amount) > 0
  );
  const cashesCount = cashes.length;

  const totalPrize = recent.reduce(
    (sum, r) => sum + (Number(r.prize_amount) || 0),
    0
  );

  const stakesBuckets = {
    low: 0,
    mid: 0,
    high: 0,
    nosebleed: 0,
  };
  let totalBuyins = 0;

  for (const r of recent) {
    const raw = r.event?.buy_in_raw;
    if (!raw) continue;

    const numeric = Number(String(raw).replace(/[^0-9.]/g, "")) || 0;
    if (!numeric) continue;

    totalBuyins += numeric;

    if (numeric < 100) stakesBuckets.low++;
    else if (numeric < 250) stakesBuckets.mid++;
    else if (numeric < 500) stakesBuckets.high++;
    else stakesBuckets.nosebleed++;
  }

  const netProfit = totalPrize - totalBuyins;
  const itmPercentage = totalResults
    ? (cashesCount / totalResults) * 100
    : 0;

  const biggestCash = cashes.reduce(
    (max, r) => Math.max(max, Number(r.prize_amount) || 0),
    0
  );

  const bestFinish = recent.reduce((best, r) => {
    if (typeof r.position_of_prize === "number") {
      return best === null ? r.position_of_prize : Math.min(best, r.position_of_prize);
    }
    return best;
  }, null as number | null);

  const lastPlayed =
    recent[0]?.event?.start_date || recent[0]?.created_at || null;

  const siteCounts = new Map<string, number>();
  for (const r of recent) {
    const label = r.event?.site_name || "Unknown";
    siteCounts.set(label, (siteCounts.get(label) ?? 0) + 1);
  }
  const topSites = Array.from(siteCounts.entries())
    .sort((a, b) => b[1] - a[1])
    .slice(0, 3);

  const stakesList = [
    { label: "< £100", value: stakesBuckets.low },
    { label: "£100 – £249", value: stakesBuckets.mid },
    { label: "£250 – £499", value: stakesBuckets.high },
    { label: "£500+", value: stakesBuckets.nosebleed },
  ];

  const achievementBadges = [
    "GUKPT Winner",
    "NPL Winner",
    "25/50 Winner",
    "Current Season Top 10",
  ];

  // ✅ Lifetime points nicely capped to 2 decimals
  const lifetimePoints = Number(data.stats.lifetime_points ?? 0);

  return (
    <div className="space-y-6">
      {/* Header / identity */}
      <section className="card bg-base-100 shadow-sm">
        <div className="card-body flex flex-wrap items-center justify-between gap-6">
          <div className="flex items-center gap-4">
            <div className="avatar">
              <div className="w-16 rounded-full ring ring-primary ring-offset-base-100 ring-offset-2 overflow-hidden">
                {/* eslint-disable-next-line @next/next/no-img-element */}
                <img
                  src={p.avatar_url || PLACEHOLDER_AVATAR_URL}
                  alt={p.name ?? ""}
                  className="w-full h-full object-cover"
                />
              </div>
            </div>

            <div>
              <h1 className="card-title text-2xl">{p.name}</h1>
              <p className="text-sm text-base-content/60 mt-1">
                National Poker League player
              </p>

              <div className="mt-2 flex flex-wrap gap-1">
                {achievementBadges.map((badge) => (
                  <span
                    key={badge}
                    className="badge badge-ghost badge-xs border border-base-300 text-[0.65rem]"
                  >
                    {badge}
                  </span>
                ))}
              </div>
            </div>
          </div>

          <div className="text-right text-xs sm:text-sm text-base-content/60 space-y-1">
            {lastPlayed && (
              <p>
                Last played:{" "}
                {new Date(lastPlayed).toLocaleDateString("en-GB")}
              </p>
            )}
            <p>Results shown: last {totalResults || 0} (max 30)</p>
          </div>
        </div>
      </section>

      {/* ✅ Stats now in a responsive grid, not one huge line */}
      <section className="card bg-base-100 shadow-sm">
        <div className="card-body space-y-4">
          <h2 className="card-title">Stats overview</h2>
          <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-4">
            <div className="stat bg-base-200/40 rounded-xl">
              <div className="stat-title text-xs">Lifetime points</div>
              <div className="stat-value text-2xl">
                {lifetimePoints.toFixed(2)}
              </div>
              <div className="stat-desc text-xs">
                Across all recorded results
              </div>
            </div>

            <div className="stat bg-base-200/40 rounded-xl">
              <div className="stat-title text-xs">Results (last 30)</div>
              <div className="stat-value text-2xl">
                {totalResults}
              </div>
              <div className="stat-desc text-xs">
                Avg {avgPointsRecent.toFixed(2)} pts per result
              </div>
            </div>

            <div className="stat bg-base-200/40 rounded-xl">
              <div className="stat-title text-xs">ITM (last 30)</div>
              <div className="stat-value text-2xl">
                {totalResults ? `${itmPercentage.toFixed(0)}%` : "–"}
              </div>
              <div className="stat-desc text-xs">
                {cashesCount} cashes from {totalResults} results
              </div>
            </div>

            <div className="stat bg-base-200/40 rounded-xl">
              <div className="stat-title text-xs">
                Net profit (last 30, approx)
              </div>
              <div className="stat-value text-2xl">
                {netProfit === 0
                  ? "–"
                  : `${netProfit >= 0 ? "£" : "-£"}${Math.abs(
                      Math.round(netProfit)
                    )}`}
              </div>
              <div className="stat-desc text-xs">
                Winnings vs recorded buy-ins
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* NPL performance (placeholder) */}
      <section className="card bg-base-100 shadow-sm">
        <div className="card-body space-y-3">
          <div className="flex items-center justify-between gap-2">
            <h2 className="card-title">NPL performance</h2>
            <span className="badge badge-ghost badge-xs">Coming soon</span>
          </div>
          <p className="text-xs text-base-content/60">
            Once season ranking data is wired in, this section will show how
            their position in the National Poker League leaderboard has moved
            from their first result to today.
          </p>
          <div className="h-40 md:h-56 rounded-xl border border-dashed border-base-300 bg-base-200/40 flex items-center justify-center text-xs text-base-content/60">
            Position over time chart placeholder
          </div>
        </div>
      </section>

      {/* Game profile */}
      <section className="card bg-base-100 shadow-sm">
        <div className="card-body space-y-3">
          <h2 className="card-title">Game profile (last 30 results)</h2>
          <div className="grid gap-4 md:grid-cols-3">
            <div className="space-y-2 text-sm">
              <h3 className="font-medium text-sm">Preferred stakes</h3>
              <ul className="space-y-1 text-xs text-base-content/70">
                {stakesList.map((b) => (
                  <li key={b.label} className="flex justify-between">
                    <span>{b.label}</span>
                    <span className="font-mono">{b.value}</span>
                  </li>
                ))}
              </ul>
            </div>

            <div className="space-y-2 text-sm">
              <h3 className="font-medium text-sm">Top venues</h3>
              {topSites.length === 0 ? (
                <p className="text-xs text-base-content/60">
                  No venue data yet.
                </p>
              ) : (
                <ul className="space-y-1 text-xs text-base-content/70">
                  {topSites.map(([site, count]) => (
                    <li key={site} className="flex justify-between">
                      <span>{site}</span>
                      <span className="font-mono">{count}</span>
                    </li>
                  ))}
                </ul>
              )}
            </div>

            <div className="space-y-2 text-sm">
              <h3 className="font-medium text-sm">Highlights</h3>
              <ul className="space-y-1 text-xs text-base-content/70">
                <li>
                  <span className="font-semibold">Biggest cash:</span>{" "}
                  {biggestCash > 0 ? `£${biggestCash}` : "–"}
                </li>
                <li>
                  <span className="font-semibold">Best finish:</span>{" "}
                  {bestFinish !== null ? `#${bestFinish}` : "–"}
                </li>
                <li>
                  <span className="font-semibold">
                    Total winnings (last 30):
                  </span>{" "}
                  {totalPrize > 0 ? `£${Math.round(totalPrize)}` : "–"}
                </li>
              </ul>
            </div>
          </div>
        </div>
      </section>

      {/* Recent results */}
      <section className="card bg-base-100 shadow-sm">
        <div className="card-body space-y-3">
          <h2 className="card-title">Recent results</h2>
          {recent.length === 0 ? (
            <p className="text-sm text-base-content/60">
              No recent results recorded.
            </p>
          ) : (
            <ul className="space-y-2">
              {recent.map((r) => {
                const cashed =
                  r.prize_amount !== null && Number(r.prize_amount) > 0;

                return (
                  <li
                    key={r.id}
                    className="rounded-xl border border-base-300 bg-base-100 p-3 space-y-1"
                  >
                    <div className="flex flex-wrap items-center justify-between gap-2">
                      <div className="flex flex-col gap-1">
                        <div className="font-medium">
                          {r.event?.name || "Event"}
                        </div>
                        <div className="flex flex-wrap items-center gap-2 text-xs text-base-content/60">
                          <span
                            className={`badge badge-xs ${
                              cashed ? "badge-success" : "badge-ghost"
                            }`}
                          >
                            {cashed ? "Cashed" : "Played"}
                          </span>
                          {typeof r.position_of_prize === "number" && (
                            <span className="badge badge-ghost badge-xs">
                              #{r.position_of_prize}
                            </span>
                          )}
                        </div>
                      </div>

                      <div className="text-sm text-base-content/60 text-right">
                        {r.event?.start_date
                          ? new Date(
                              r.event.start_date
                            ).toLocaleDateString("en-GB")
                          : ""}
                      </div>
                    </div>

                    <div className="text-sm text-base-content/80">
                      {r.points ?? 0} pts •{" "}
                      {r.prize_amount ? `£${r.prize_amount}` : "–"}
                    </div>

                    <div className="text-xs text-base-content/60">
                      {r.event?.site_name ? `Site: ${r.event.site_name}` : ""}
                      {r.event?.buy_in_raw
                        ? ` • Buy-in: ${r.event.buy_in_raw}`
                        : ""}
                    </div>
                  </li>
                );
              })}
            </ul>
          )}
        </div>
      </section>

      <div>
        <Link href="/players" className="btn btn-ghost btn-sm">
          ← Back to players
        </Link>
      </div>
    </div>
  );
}
