// src/lib/supabaseServer.ts
import { cookies } from "next/headers";
import {
  createServerClient,
  type CookieOptions,
  type CookieMethodsServer,
} from "@supabase/ssr";

/**
 * Next 15: cookies() must be awaited.
 * We return cookie methods that await cookies() on each call.
 *
 * mode = 'rsc'  -> used in Server Components (no cookie writes)
 * mode = 'route'-> used in Route Handlers (writes allowed)
 */
type Mode = "rsc" | "route";

function cookieMethods(mode: Mode): CookieMethodsServer {
  return {
    // read
    get: async (name: string) => {
      const store = await cookies();
      return store.get(name)?.value;
    },
    // write (only in route handlers)
    set: async (name: string, value: string, options: CookieOptions) => {
      if (mode !== "route") return; // no-op in RSC to avoid warnings
      const store = await cookies();
      store.set({ name, value, ...options });
    },
    // remove (only in route handlers)
    remove: async (name: string, options: CookieOptions) => {
      if (mode !== "route") return; // no-op in RSC to avoid warnings
      const store = await cookies();
      store.set({ name, value: "", ...options });
    },
  } as unknown as CookieMethodsServer;
}

/**
 * Use in Server Components / server pages.
 * Default is 'rsc' to avoid cookie write warnings.
 */
export async function createSupabaseServerClient(mode: Mode = "rsc") {
  return createServerClient(
    process.env.NEXT_PUBLIC_SUPABASE_URL!,
    process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!,
    { cookies: cookieMethods(mode) }
  );
}

/**
 * Convenience for Route Handlers where cookie writes are allowed.
 */
export async function createSupabaseRouteClient() {
  return createServerClient(
    process.env.NEXT_PUBLIC_SUPABASE_URL!,
    process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!,
    { cookies: cookieMethods("route") }
  );
}
