// postcss.config.mjs  (or postcss.config.js)
export default {
  plugins: {
    "@tailwindcss/postcss": {},
  },
};
