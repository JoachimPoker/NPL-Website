// src/app/admin/layout.tsx
import { ReactNode } from "react";
import { headers } from "next/headers";
import { createSupabaseServerClient } from "@/lib/supabaseServer";

export const runtime = "nodejs";
export const revalidate = 0;

type Props = { children: ReactNode };

// Map pathname → human title
function titleFor(path: string) {
  // normalize to just the /admin/* part
  const p = path || "/admin";
  if (p === "/admin") return "Dashboard";
  if (p.startsWith("/admin/seasons")) return "Seasons";
  if (p.startsWith("/admin/import")) return "Import";
  if (p.startsWith("/admin/series")) return "Series";
  if (p.startsWith("/admin/players")) return "Players";
  return "Admin";
}

function isOn(pathname: string, href: string) {
  return pathname === href || pathname.startsWith(href + "/");
}

export default async function AdminLayout({ children }: Props) {
  // figure out current path (works in dev/prod)
  const h = await headers();
  const pathname =
    h.get("next-url") ||
    h.get("x-invoke-path") ||
    h.get("x-matched-path") ||
    "/admin";

  // get current user to show email + admin tag
  const supabase = await createSupabaseServerClient();
  const { data } = await supabase.auth.getUser();
  const user = data?.user;
  const email =
    (user?.email as string | undefined) ||
    (user?.user_metadata as any)?.email ||
    "Admin";
  const roles = ((user?.app_metadata as any)?.roles ?? []) as string[];
  const isAdmin = roles?.includes("admin") || (user?.user_metadata as any)?.is_admin;

  const pageTitle = titleFor(pathname);

  const NavLink = ({
    href,
    children,
  }: {
    href: string;
    children: React.ReactNode;
  }) => (
    <a
      href={href}
      className={`btn btn-ghost btn-sm ${
        isOn(pathname, href) ? "btn-active font-semibold" : ""
      }`}
    >
      {children}
    </a>
  );

  return (
    <div className="space-y-6">
      {/* Top admin card shown on every /admin/* page */}
      <section className="card bg-base-100 shadow-sm">
        <div className="card-body">
          <div className="flex flex-wrap items-start justify-between gap-3">
            <div className="space-y-1">
              <h1 className="text-lg font-semibold">Admin — {pageTitle}</h1>
              <div className="text-sm text-base-content/70">
                Signed in as <span className="font-medium">{email}</span>
                {isAdmin ? " · Admin" : ""}
              </div>
            </div>

            <div className="flex flex-wrap items-center gap-2">
              <NavLink href="/admin/seasons">Seasons</NavLink>
              <NavLink href="/admin/import-excel">Import</NavLink>
              <NavLink href="/admin/series">Series</NavLink>
              <NavLink href="/admin/players">Players</NavLink>
            </div>
          </div>

          <div className="mt-3">
            <a href="/auth/signout" className="btn btn-ghost btn-sm">
              Sign out
            </a>
          </div>
        </div>
      </section>

      {/* Page content */}
      {children}
    </div>
  );
}
