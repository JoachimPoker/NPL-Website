// src/app/admin/seasons/page.tsx
"use client";

import { useEffect, useMemo, useState } from "react";

type Season = {
  id?: number;
  label: string;
  start_date: string; // YYYY-MM-DD
  end_date: string; // YYYY-MM-DD
  method: "ALL" | "BEST_X";
  cap_x: number | null;
  notes: string | null;
  prize_bands: Array<{ from: number; to: number; text: string }>;
  is_active: boolean;
  created_at?: string;
  updated_at?: string;
};

type ListResp = { seasons: Season[]; _error?: string };

const emptySeason: Season = {
  label: "",
  start_date: "",
  end_date: "",
  method: "ALL",
  cap_x: null,
  notes: "",
  prize_bands: [],
  is_active: false,
};

export default function AdminSeasonsPage() {
  const [list, setList] = useState<Season[]>([]);
  const [loading, setLoading] = useState(false);
  const [editing, setEditing] = useState<Season | null>(null);
  const [err, setErr] = useState<string | null>(null);
  const [ok, setOk] = useState<string | null>(null);

  async function fetchList() {
    setLoading(true);
    setErr(null);
    try {
      const res = await fetch("/api/admin/seasons/list", { cache: "no-store" });
      const json = (await res.json()) as ListResp;
      if (!res.ok) throw new Error(json._error || res.statusText);
      setList(json.seasons || []);
    } catch (e: any) {
      setErr(e?.message || String(e));
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => {
    fetchList();
  }, []);

  const startCreate = () => {
    setEditing({ ...emptySeason });
    setOk(null);
    setErr(null);
  };

  const startEdit = (s: Season) => {
    // deep clone to avoid mutating list while editing
    setEditing(JSON.parse(JSON.stringify(s)));
    setOk(null);
    setErr(null);
  };

  const cancelEdit = () => {
    setEditing(null);
  };

  const save = async () => {
    if (!editing) return;
    setLoading(true);
    setErr(null);
    setOk(null);
    try {
      const body = {
        id: editing.id ?? null,
        label: editing.label.trim(),
        start_date: editing.start_date,
        end_date: editing.end_date,
        method: editing.method,
        cap_x: editing.method === "BEST_X" ? Number(editing.cap_x || 20) : null,
        notes: editing.notes || "",
        prize_bands: (editing.prize_bands || []).map((b) => ({
          from: Number(b.from),
          to: Number(b.to ?? b.from),
          text: String(b.text || "").trim(),
        })),
        is_active: !!editing.is_active,
      };
      const res = await fetch("/api/admin/seasons/upsert", {
        method: "POST",
        headers: { "content-type": "application/json" },
        body: JSON.stringify(body),
      });
      const json = await res.json();
      if (!res.ok) throw new Error(json._error || res.statusText);
      setOk("Saved.");
      setEditing(null);
      fetchList();
    } catch (e: any) {
      setErr(e?.message || String(e));
    } finally {
      setLoading(false);
    }
  };

  const setActive = async (id: number) => {
    setLoading(true);
    setErr(null);
    setOk(null);
    try {
      const res = await fetch("/api/admin/seasons/set-active", {
        method: "POST",
        headers: { "content-type": "application/json" },
        body: JSON.stringify({ id }),
      });
      const json = await res.json();
      if (!res.ok) throw new Error(json._error || res.statusText);
      setOk("Active season updated.");
      fetchList();
    } catch (e: any) {
      setErr(e?.message || String(e));
    } finally {
      setLoading(false);
    }
  };

  const remove = async (id: number) => {
    if (!confirm("Delete this season?")) return;
    setLoading(true);
    setErr(null);
    setOk(null);
    try {
      const res = await fetch("/api/admin/seasons/delete", {
        method: "POST",
        headers: { "content-type": "application/json" },
        body: JSON.stringify({ id }),
      });
      const json = await res.json();
      if (!res.ok) throw new Error(json._error || res.statusText);
      setOk("Deleted.");
      fetchList();
    } catch (e: any) {
      setErr(e?.message || String(e));
    } finally {
      setLoading(false);
    }
  };

  // Prize bands helpers
  const addBand = () => {
    if (!editing) return;
    setEditing({
      ...editing,
      prize_bands: [...(editing.prize_bands || []), { from: 1, to: 1, text: "" }],
    });
  };

  const updateBand = (
    idx: number,
    patch: Partial<{ from: number; to: number; text: string }>
  ) => {
    if (!editing) return;
    const next = [...(editing.prize_bands || [])];
    next[idx] = { ...next[idx], ...patch } as any;
    setEditing({ ...editing, prize_bands: next });
  };

  const removeBand = (idx: number) => {
    if (!editing) return;
    const next = [...(editing.prize_bands || [])];
    next.splice(idx, 1);
    setEditing({ ...editing, prize_bands: next });
  };

  const activeId = useMemo(() => list.find((s) => s.is_active)?.id, [list]);
  // activeId is computed for potential future use (e.g. highlighting), but not required in UI yet.

  return (
    <div className="space-y-6">
      {/* Local toolbar (main header is provided by /admin/layout.tsx) */}
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div className="text-sm text-base-content/70">
          Define season windows, scoring method and prize bands.
        </div>
        <div className="flex flex-wrap items-center gap-2">
          <button
            className="btn btn-primary btn-sm"
            onClick={startCreate}
            disabled={!!editing}
          >
            + New Season
          </button>
          <button
            className="btn btn-outline btn-sm"
            onClick={fetchList}
            disabled={loading}
          >
            Refresh
          </button>
        </div>
      </div>

      {err && (
        <div className="alert alert-error text-sm">
          <span>{err}</span>
        </div>
      )}
      {ok && (
        <div className="alert alert-success text-sm">
          <span>{ok}</span>
        </div>
      )}

      {/* Editor */}
      {editing && (
        <div className="card bg-base-100 shadow-sm">
          <div className="card-body space-y-4">
            <div className="grid gap-4 md:grid-cols-2">
              <div>
                <label className="label">
                  <span className="label-text text-sm">Label</span>
                </label>
                <input
                  className="input input-bordered input-sm w-full"
                  value={editing.label}
                  onChange={(e) =>
                    setEditing({ ...editing, label: e.target.value })
                  }
                  placeholder="Season 8"
                />
              </div>

              <div className="flex items-end justify-end">
                <label className="label cursor-pointer gap-2">
                  <span className="label-text text-sm">Set active</span>
                  <input
                    type="checkbox"
                    className="checkbox checkbox-sm"
                    checked={editing.is_active}
                    onChange={(e) =>
                      setEditing({ ...editing, is_active: e.target.checked })
                    }
                  />
                </label>
              </div>

              <div>
                <label className="label">
                  <span className="label-text text-sm">Start Date</span>
                </label>
                <input
                  type="date"
                  className="input input-bordered input-sm w-full"
                  value={editing.start_date}
                  onChange={(e) =>
                    setEditing({ ...editing, start_date: e.target.value })
                  }
                />
              </div>
              <div>
                <label className="label">
                  <span className="label-text text-sm">End Date</span>
                </label>
                <input
                  type="date"
                  className="input input-bordered input-sm w-full"
                  value={editing.end_date}
                  onChange={(e) =>
                    setEditing({ ...editing, end_date: e.target.value })
                  }
                />
              </div>

              <div>
                <label className="label">
                  <span className="label-text text-sm">Method</span>
                </label>
                <select
                  className="select select-bordered select-sm w-full"
                  value={editing.method}
                  onChange={(e) => {
                    const m = e.target.value as "ALL" | "BEST_X";
                    setEditing({
                      ...editing,
                      method: m,
                      cap_x: m === "BEST_X" ? editing.cap_x ?? 20 : null,
                    });
                  }}
                >
                  <option value="ALL">ALL (no cap)</option>
                  <option value="BEST_X">BEST X</option>
                </select>
              </div>

              <div>
                <label className="label">
                  <span className="label-text text-sm">Cap (for BEST_X)</span>
                </label>
                <input
                  type="number"
                  min={1}
                  max={1000}
                  className="input input-bordered input-sm w-full"
                  value={editing.cap_x ?? ""}
                  onChange={(e) =>
                    setEditing({
                      ...editing,
                      cap_x: e.target.value ? Number(e.target.value) : null,
                    })
                  }
                  disabled={editing.method !== "BEST_X"}
                />
              </div>

              <div className="md:col-span-2">
                <label className="label">
                  <span className="label-text text-sm">Notes</span>
                </label>
                <textarea
                  className="textarea textarea-bordered textarea-sm w-full"
                  rows={3}
                  value={editing.notes ?? ""}
                  onChange={(e) =>
                    setEditing({ ...editing, notes: e.target.value })
                  }
                  placeholder="Any special rules (e.g., Season 7 starts 10/12/2024)"
                />
              </div>
            </div>

            {/* Prize bands */}
            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <label className="text-sm font-medium">Prize bands</label>
                <button
                  className="btn btn-ghost btn-xs"
                  type="button"
                  onClick={addBand}
                >
                  + Add band
                </button>
              </div>

              {!editing.prize_bands?.length ? (
                <p className="text-sm text-base-content/60">
                  No prize bands yet.
                </p>
              ) : (
                <div className="space-y-2">
                  {editing.prize_bands.map((b, idx) => (
                    <div
                      key={idx}
                      className="grid items-end gap-2 md:grid-cols-8"
                    >
                      <div className="md:col-span-1">
                        <label className="label">
                          <span className="label-text text-xs">From</span>
                        </label>
                        <input
                          type="number"
                          min={1}
                          className="input input-bordered input-xs w-full"
                          value={b.from}
                          onChange={(e) =>
                            updateBand(idx, {
                              from: Number(e.target.value || 1),
                            })
                          }
                        />
                      </div>
                      <div className="md:col-span-1">
                        <label className="label">
                          <span className="label-text text-xs">To</span>
                        </label>
                        <input
                          type="number"
                          min={1}
                          className="input input-bordered input-xs w-full"
                          value={b.to}
                          onChange={(e) =>
                            updateBand(idx, {
                              to: Number(e.target.value || b.from),
                            })
                          }
                        />
                      </div>
                      <div className="md:col-span-5">
                        <label className="label">
                          <span className="label-text text-xs">Text</span>
                        </label>
                        <input
                          className="input input-bordered input-xs w-full"
                          value={b.text}
                          onChange={(e) =>
                            updateBand(idx, { text: e.target.value })
                          }
                          placeholder="e.g., £250 credit"
                        />
                      </div>
                      <div className="md:col-span-1">
                        <button
                          className="btn btn-ghost btn-xs w-full"
                          type="button"
                          onClick={() => removeBand(idx)}
                        >
                          Remove
                        </button>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>

            <div className="flex flex-wrap items-center gap-2">
              <button
                className="btn btn-primary btn-sm"
                type="button"
                onClick={save}
                disabled={loading}
              >
                Save
              </button>
              <button
                className="btn btn-ghost btn-sm"
                type="button"
                onClick={cancelEdit}
                disabled={loading}
              >
                Cancel
              </button>
              {editing.id ? (
                <>
                  <button
                    className="btn btn-outline btn-sm"
                    type="button"
                    onClick={() => editing?.id && setActive(editing.id)}
                    disabled={loading || editing.is_active}
                    title={
                      editing.is_active
                        ? "Already active"
                        : "Set as active season"
                    }
                  >
                    Set active
                  </button>
                  <button
                    className="btn btn-error btn-sm"
                    type="button"
                    onClick={() => editing?.id && remove(editing.id)}
                    disabled={loading}
                  >
                    Delete
                  </button>
                </>
              ) : null}
            </div>
          </div>
        </div>
      )}

      {/* List */}
      <div className="card overflow-hidden bg-base-100 shadow-sm">
        <div className="card-body flex items-center justify-between border-b border-base-200">
          <b>Seasons</b>
          <button
            className="btn btn-ghost btn-xs"
            type="button"
            onClick={fetchList}
            disabled={loading}
          >
            Refresh
          </button>
        </div>
        <div className="card-body p-0 overflow-x-auto">
          {loading && !list.length ? (
            <p className="p-4 text-sm text-base-content/70">Loading…</p>
          ) : !list.length ? (
            <p className="p-4 text-sm text-base-content/70">No seasons yet.</p>
          ) : (
            <table className="table table-sm w-full">
              <thead>
                <tr>
                  <th className="text-left">Label</th>
                  <th className="text-left">Dates</th>
                  <th className="text-left">Method</th>
                  <th className="text-left">Cap</th>
                  <th className="text-left">Active</th>
                  <th className="text-left">Prizes</th>
                  <th className="w-40 text-left">Actions</th>
                </tr>
              </thead>
              <tbody>
                {list.map((s) => (
                  <tr key={s.id}>
                    <td className="font-medium">{s.label}</td>
                    <td>
                      {s.start_date} → {s.end_date}
                    </td>
                    <td>{s.method}</td>
                    <td>{s.method === "BEST_X" ? s.cap_x ?? "—" : "—"}</td>
                    <td>
                      {s.is_active ? (
                        <span className="badge badge-success badge-sm">
                          Active
                        </span>
                      ) : (
                        "—"
                      )}
                    </td>
                    <td>
                      {s.prize_bands?.length ? (
                        <div className="flex flex-wrap gap-1">
                          {s.prize_bands.map((b, i) => (
                            <span
                              key={i}
                              className="badge badge-ghost badge-sm"
                            >
                              {b.from === b.to
                                ? b.from
                                : `${b.from}-${b.to}`}
                              : {b.text}
                            </span>
                          ))}
                        </div>
                      ) : (
                        <span className="text-xs text-base-content/60">—</span>
                      )}
                    </td>
                    <td>
                      <div className="flex flex-wrap gap-2">
                        <button
                          className="btn btn-ghost btn-xs"
                          type="button"
                          onClick={() => startEdit(s)}
                        >
                          Edit
                        </button>
                        {!s.is_active && s.id ? (
                          <button
                            className="btn btn-outline btn-xs"
                            type="button"
                            onClick={() => setActive(s.id!)}
                          >
                            Set active
                          </button>
                        ) : null}
                        {s.id ? (
                          <button
                            className="btn btn-error btn-xs"
                            type="button"
                            onClick={() => remove(s.id!)}
                          >
                            Delete
                          </button>
                        ) : null}
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          )}
        </div>
      </div>
    </div>
  );
}
