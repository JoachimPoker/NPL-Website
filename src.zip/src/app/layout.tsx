// src/app/layout.tsx
import './globals.css'
import { Inter } from 'next/font/google'
import { headers } from 'next/headers'
import { createSupabaseServerClient } from '@/lib/supabaseServer'

export const runtime = 'nodejs'

export const metadata = {
  title: 'National Poker League',
  description: 'Official leaderboards and player stats.',
  icons: { icon: '/favicon.ico' },
}

const inter = Inter({ subsets: ['latin'] })

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en" data-theme="night" className="h-full">
      <body className={`${inter.className} min-h-full antialiased`}>
        <SiteShell>{children}</SiteShell>
      </body>
    </html>
  )
}

// ---- Shell (server component) ----
async function SiteShell({ children }: { children: React.ReactNode }) {
  return (
    <div className="flex min-h-screen flex-col bg-base-200 text-base-content">
      <SiteHeader />
      <main className="flex-1">
        <Container className="py-6 space-y-6">{children}</Container>
      </main>
      <SiteFooter />
    </div>
  )
}

// ---- Shared primitives ----
function Container({
  children,
  className = '',
}: {
  children: React.ReactNode
  className?: string
}) {
  return <div className={`mx-auto w-full max-w-6xl px-4 sm:px-6 ${className}`}>{children}</div>
}

async function SiteHeader() {
  return (
    <header className="sticky top-0 z-40 border-b border-base-200 bg-base-100/90 backdrop-blur">
      <div className="mx-auto w-full max-w-6xl px-4 sm:px-6">
        <div className="navbar px-0">
          <div className="flex-1">
            <a href="/" className="btn btn-ghost px-0 gap-2 text-lg font-semibold">
              <div className="grid h-8 w-8 place-items-center rounded-lg bg-neutral text-neutral-content text-sm">
                N
              </div>
              <span>National Poker League</span>
            </a>
          </div>
          <div className="flex-none">
            {/* dynamic nav */}
            <Nav />
          </div>
        </div>
      </div>
    </header>
  )
}

// Dynamic nav (server component)
async function Nav() {
  // ✅ use read-only Supabase client in Server Component
  const supabase = await createSupabaseServerClient({ mode: 'readonly' })
  const { data } = await supabase.auth.getUser().catch(() => ({ data: { user: null } as any }))
  const user = data?.user ?? null

  const roles: string[] = (user?.app_metadata?.roles ?? []) as any
  const isAdmin =
    roles?.includes?.('admin') ||
    user?.app_metadata?.role === 'admin' ||
    user?.user_metadata?.is_admin === true

  const h = await headers()
  const pathname =
    h.get('next-url') || h.get('x-invoke-path') || h.get('x-matched-path') || '/'

  const on = (p: string) => pathname === p || pathname.startsWith(p + '/')

  const link = (href: string, label: string) => (
    <li key={href}>
      <a
        href={href}
        className={`btn btn-ghost btn-sm normal-case ${
          on(href) ? 'btn-active font-semibold' : ''
        }`}
      >
        {label}
      </a>
    </li>
  )

  return (
    <nav>
      <ul className="menu menu-horizontal px-0 gap-1">
        {link('/leaderboards', 'Leaderboards')}
        {link('/events', 'Events')}
        {link('/players', 'Players')}
        {isAdmin && link('/admin', 'Admin')}

        {user ? (
          <li>
            {/* Sign out must be a POST → use a small form styled like a button */}
            <form action="/auth/signout" method="post">
              <button className="btn btn-ghost btn-sm normal-case">Log out</button>
            </form>
          </li>
        ) : (
          link('/login', 'Log in')
        )}
      </ul>
    </nav>
  )
}

function SiteFooter() {
  return (
    <footer className="border-t border-base-200 bg-base-100">
      <Container className="py-6">
        <div className="footer footer-horizontal items-center justify-between gap-4 text-xs text-base-content">
          <aside>
            © {new Date().getFullYear()} National Poker League
          </aside>
          <nav className="flex items-center gap-4">
            <a className="link link-hover" href="/leaderboards">
              Leaderboards
            </a>
            <a className="link link-hover" href="/players">
              Players
            </a>
            <a className="link link-hover" href="/privacy">
              Privacy
            </a>
          </nav>
        </div>
      </Container>
    </footer>
  )
}
