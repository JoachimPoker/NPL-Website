// src/app/leaderboards/page.tsx
import { headers } from "next/headers";
import Link from "next/link";

export const runtime = "nodejs";
export const revalidate = 0;

/* ---------- Types matching /api/leaderboards/season ---------- */
type MetaSeason = {
  id: number;
  label: string;
  start_date: string;
  end_date: string;
  method: "ALL" | "BEST_X";
  cap_x: number | null;
  is_active: boolean;
};

type Row = {
  position: number;
  player_id: string;
  display_name: string;
  total_points: number;
  used_count: number;
  total_count: number;
  average_used: number;
  average_all: number;
  best_single: number;
  lowest_counted: number | null;
  top3_count: number;
  top9_count: number;
  wins: number;
};

type SuccessResp = {
  ok: true;
  meta: {
    league: "npl" | "hrl";
    season: MetaSeason;
    limit: number;
    offset: number;
    total_hint?: number;
  };
  rows: Row[];
};

type ErrorResp = { ok: false; error: string };
type ApiResp = SuccessResp | ErrorResp;

/* ---------- Helpers ---------- */
async function baseUrl() {
  const h = await headers();
  const host = h.get("x-forwarded-host") ?? h.get("host") ?? "localhost:3000";
  const proto = h.get("x-forwarded-proto") ?? "http";
  return `${proto}://${host}`;
}

function qs(obj: Record<string, string | number | undefined | null>) {
  const p = new URLSearchParams();
  for (const [k, v] of Object.entries(obj)) {
    if (v === undefined || v === null || v === "") continue;
    p.set(k, String(v));
  }
  const s = p.toString();
  return s ? `?${s}` : "";
}

function fmt(v: number | null | undefined) {
  if (v === null || v === undefined) return "—";
  return v.toFixed(2);
}

function isSuccess(x: unknown): x is SuccessResp {
  return !!x && typeof x === "object" && (x as any).ok === true && Array.isArray((x as any).rows);
}

/* ---------- Page (server) ---------- */
export default async function LeaderboardsPage({
  searchParams,
}: {
  // Next 15: searchParams is async
  searchParams: Promise<Record<string, string | string[] | undefined>>;
}) {
  const spRaw = await searchParams;
  const sp = Object.fromEntries(
    Object.entries(spRaw ?? {}).map(([k, v]) => [k, Array.isArray(v) ? v[0] : v])
  );

  // defaults
  const league = (sp.league === "hrl" ? "hrl" : "npl") as "npl" | "hrl";
  const seasonId = sp.seasonId || "current";
  const method =
    sp.method?.toUpperCase() === "BEST_X"
      ? "BEST_X"
      : sp.method?.toUpperCase() === "ALL"
      ? "ALL"
      : undefined;
  const cap = sp.cap ? Number(sp.cap) : undefined;
  const q = (sp.q || sp.search || "").trim();
  const pageSize = Math.min(500, Math.max(10, Number(sp.limit ?? 100)));
  const page = Math.max(1, Number(sp.page ?? 1));
  const offset = (page - 1) * pageSize;

  // Build API query
  const apiParams: Record<string, string | number | undefined> = {
    league,
    seasonId,
    limit: pageSize,
    offset,
    q: q || undefined,
    method,
    cap: method === "BEST_X" ? cap : undefined,
  };
  const apiUrl = `${await baseUrl()}/api/leaderboards/season${qs(apiParams)}`;

  const res = await fetch(apiUrl, { cache: "no-store" });
  const data = (await res.json()) as ApiResp;

  if (!res.ok || !isSuccess(data)) {
    const msg = (!res.ok ? res.statusText : (data as ErrorResp).error) || "Unknown error";
    return (
      <main className="space-y-6">
        <section className="card bg-base-200/60">
          <div className="card-body gap-4">
            <h1 className="card-title text-2xl">Leaderboards</h1>
            <div className="alert alert-error">
              <span>Failed to load leaderboard: {msg}</span>
            </div>
          </div>
        </section>
      </main>
    );
  }

  const meta = data.meta;
  const rows = data.rows;
  const hasPrev = page > 1;
  const hasNext = rows.length === pageSize; // optimistic; no exact total needed

  // helpers to build navigation/search URLs
  const baseParams = {
    seasonId,
    q: q || undefined,
    method: method || undefined,
    cap: method === "BEST_X" ? (cap ?? meta.season.cap_x ?? undefined) : undefined,
    limit: pageSize,
  };

  const makeUrl = (extra: Record<string, string | number | undefined>) =>
    `/leaderboards${qs({ ...baseParams, league, ...extra })}`;

  const season = meta.season;
  const effectiveMethod = (sp.method?.toUpperCase() as "ALL" | "BEST_X") || season.method;
  const effectiveCap = (sp.cap ?? season.cap_x ?? 0) as number;

  return (
    <main className="space-y-6">
      {/* HERO / CONTROLS */}
      <section className="card bg-base-200/60 shadow-md">
        <div className="card-body gap-6">
          <div className="space-y-2 text-center">
            <h1 className="card-title justify-center text-3xl">Leaderboards</h1>
            <p className="text-sm text-base-content/70">
              Season <span className="font-semibold">{season.label}</span> ·{" "}
              {season.start_date} → {season.end_date}
            </p>
            <p className="text-xs text-base-content/60">
              Scoring method:{" "}
              {season.method === "BEST_X"
                ? `Best ${season.cap_x ?? "X"} results count`
                : "All results count"}
            </p>
          </div>

          {/* League toggle */}
          <div className="flex justify-center">
            <div className="join">
              <Link
                href={`/leaderboards${qs({ ...baseParams, league: "npl", page: 1 })}`}
                className={`join-item btn btn-sm md:btn-md ${
                  league === "npl" ? "btn-primary" : "btn-outline"
                }`}
              >
                NPL
              </Link>
              <Link
                href={`/leaderboards${qs({ ...baseParams, league: "hrl", page: 1 })}`}
                className={`join-item btn btn-sm md:btn-md ${
                  league === "hrl" ? "btn-primary" : "btn-outline"
                }`}
              >
                High Roller League
              </Link>
            </div>
          </div>

          {/* Filters */}
          <form action="/leaderboards" method="get" className="grid gap-4 md:grid-cols-4">
            {/* keep params when submitting */}
            <input type="hidden" name="league" value={league} />
            <input type="hidden" name="seasonId" value={seasonId} />

            <div className="form-control md:col-span-2">
              <label className="label">
                <span className="label-text">Search players</span>
              </label>
              <input
                className="input input-bordered w-full"
                name="q"
                defaultValue={q}
                placeholder="Name or alias…"
              />
            </div>

            <div className="form-control">
              <label className="label">
                <span className="label-text">Method</span>
              </label>
              <select
                className="select select-bordered w-full"
                name="method"
                defaultValue={method ?? season.method}
              >
                <option value="ALL">ALL</option>
                <option value="BEST_X">BEST_X</option>
              </select>
            </div>

            <div className="form-control">
              <label className="label">
                <span className="label-text">Cap (for BEST_X)</span>
              </label>
              <input
                className="input input-bordered w-full"
                name="cap"
                type="number"
                min={0}
                defaultValue={
                  method === "BEST_X"
                    ? (cap ?? season.cap_x ?? 0)
                    : season.method === "BEST_X"
                    ? (season.cap_x ?? 0)
                    : 0
                }
              />
            </div>

            <div className="md:col-span-4 flex flex-wrap items-end gap-3">
              <div className="form-control w-full max-w-xs">
                <label className="label">
                  <span className="label-text">Page size</span>
                </label>
                <select
                  className="select select-bordered select-sm md:select-md w-full"
                  name="limit"
                  defaultValue={pageSize}
                >
                  <option value={50}>50</option>
                  <option value={100}>100</option>
                  <option value={200}>200</option>
                  <option value={500}>500</option>
                </select>
              </div>

              <button className="btn btn-primary btn-sm md:btn-md mt-2 md:mt-0" type="submit">
                Apply
              </button>

              {q && (
                <Link
                  className="btn btn-outline btn-sm md:btn-md mt-2 md:mt-0"
                  href={`/leaderboards${qs({ ...baseParams, q: undefined, page: 1, league })}`}
                >
                  Clear search
                </Link>
              )}
            </div>
          </form>
        </div>
      </section>

      {/* TABLE CARD */}
      <section className="card bg-base-200/60 overflow-hidden">
        <div className="card-body gap-4">
          <div className="flex flex-wrap items-center justify-between gap-2">
            <div className="space-y-1">
              <h2 className="card-title text-base md:text-lg">
                {league === "npl" ? "National Poker League" : "High Roller League"} —{" "}
                {season.label}
              </h2>
              <div className="flex flex-wrap items-center gap-2 text-xs md:text-sm text-base-content/70">
                <span className="badge badge-outline">
                  Method: {effectiveMethod === "BEST_X" ? "BEST_X" : "ALL"}
                </span>
                {effectiveMethod === "BEST_X" && (
                  <span className="badge badge-outline">Cap: {effectiveCap}</span>
                )}
                <span className="badge badge-ghost">
                  Page {page}
                  {meta.total_hint
                    ? ` · approx. ${meta.total_hint.toLocaleString("en-GB")} players`
                    : ""}
                </span>
              </div>
            </div>

            <div className="text-xs md:text-sm text-base-content/60">
              Showing {rows.length} of{" "}
              {pageSize.toLocaleString("en-GB")} per page
            </div>
          </div>

          {!rows.length ? (
            <div className="alert alert-info mt-2">
              <span>No results for this combination yet. Try clearing filters.</span>
            </div>
          ) : (
            <div className="overflow-x-auto">
              <table className="table table-zebra table-sm">
                <thead>
                  <tr>
                    <th className="text-left w-16">Pos</th>
                    <th className="text-left">Player</th>
                    <th className="text-right">Total</th>
                    <th className="text-right">Used</th>
                    <th className="text-right">All</th>
                    <th className="text-right">Avg (used)</th>
                    <th className="text-right">Avg (all)</th>
                    <th className="text-right">Best</th>
                    <th className="text-right">Lowest</th>
                    <th className="text-right">Wins</th>
                    <th className="text-right">Top-3</th>
                    <th className="text-right">Top-9</th>
                  </tr>
                </thead>
                <tbody>
                  {rows.map((r) => (
                    <tr key={r.player_id}>
                      <td className="nums">{r.position}</td>
                      <td className="max-w-[220px] truncate" title={r.display_name}>
                        <Link
                          className="link link-hover"
                          href={`/players/${encodeURIComponent(r.player_id)}`}
                        >
                          {r.display_name}
                        </Link>
                      </td>
                      <td className="text-right nums">{fmt(r.total_points)}</td>
                      <td className="text-right">{r.used_count}</td>
                      <td className="text-right">{r.total_count}</td>
                      <td className="text-right nums">{fmt(r.average_used)}</td>
                      <td className="text-right nums">{fmt(r.average_all)}</td>
                      <td className="text-right nums">{fmt(r.best_single)}</td>
                      <td className="text-right nums">{fmt(r.lowest_counted)}</td>
                      <td className="text-right">{r.wins}</td>
                      <td className="text-right">{r.top3_count}</td>
                      <td className="text-right">{r.top9_count}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}

          {/* Pagination */}
          <div className="mt-2 flex items-center justify-between border-t border-base-300 pt-3">
            <div className="text-xs md:text-sm text-base-content/60">
              Page {page}
              {hasNext ? ` · use Next to see more` : ""}
            </div>
            <div className="join">
              <Link
                className={`join-item btn btn-sm md:btn-md ${
                  hasPrev ? "btn-outline" : "btn-disabled"
                }`}
                href={hasPrev ? makeUrl({ page: page - 1 }) : "#"}
              >
                ← Prev
              </Link>
              <Link
                className={`join-item btn btn-sm md:btn-md ${
                  hasNext ? "btn-outline" : "btn-disabled"
                }`}
                href={hasNext ? makeUrl({ page: page + 1 }) : "#"}
              >
                Next →
              </Link>
            </div>
          </div>
        </div>
      </section>
    </main>
  );
}
