// src/app/page.tsx
import Link from "next/link";
import { headers } from "next/headers";

export const runtime = "nodejs";
export const revalidate = 0;

/* ---------- Types that mirror /api/home ---------- */
type SeasonMeta = {
  id: number;
  label: string;
  start_date: string;
  end_date: string;
  method: "ALL" | "BEST_X";
  cap_x: number;
  is_active: boolean;
};

type LbRow = {
  position: number;
  player_id: string;
  display_name: string;
  total_points: number;
  used_count: number;
  total_count: number;
  average_used: number;
  average_all: number;
  best_single: number;
  lowest_counted: number | null;
  top3_count: number;
  top9_count: number;
  wins?: number;
};

type HomeResp = {
  ok: true;
  season_meta: SeasonMeta;
  leaderboards: { npl: LbRow[]; hrl: LbRow[] };
  upcoming_events: Array<{
    id: string | number;
    name: string | null;
    start_date: string | null;
    festival_id: string | null;
    series_id: number | null;
  }>;
  trending_players: Array<{
    player_id: string;
    hits: number;
    display_name: string;
  }>;
  biggest_gainers: Array<{
    player_id: string;
    display_name: string;
    from_pos: number;
    to_pos: number;
    delta: number;
  }>;
  latest_results: Array<{
    id: string; // result id
    event_id: string | null;
    result_date: string | null; // event.start_date or created_at
    event_name: string | null;
    winner_name: string;
    prize_amount: number | null;
  }>;
};

/* ---------- Helpers ---------- */
async function baseUrl() {
  const h = await headers();
  const host = h.get("x-forwarded-host") ?? h.get("host") ?? "localhost:3000";
  const proto = h.get("x-forwarded-proto") ?? "http";
  return `${proto}://${host}`;
}

function fmtNum(v: number | null | undefined) {
  if (v === null || v === undefined) return "—";
  return v.toFixed(2);
}

function fmtGBP(v: number | null | undefined) {
  if (v === null || v === undefined) return "—";
  try {
    return new Intl.NumberFormat("en-GB", {
      style: "currency",
      currency: "GBP",
      maximumFractionDigits: 0,
    }).format(v);
  } catch {
    return v.toLocaleString("en-GB", { maximumFractionDigits: 0 });
  }
}

/* ---------- Reusable mini leaderboard ---------- */
function MiniLeaderboard({
  title,
  href,
  rows,
}: {
  title: string;
  href: string;
  rows: LbRow[];
}) {
  return (
    <div className="card bg-base-200/60">
      <div className="card-body gap-4">
        <div className="flex items-center justify-between">
          <h2 className="card-title text-lg">{title}</h2>
          <Link className="btn btn-outline btn-sm" href={href}>
            Full table
          </Link>
        </div>

        {!rows.length ? (
          <p className="text-sm text-base-content/70">No leaderboard data yet.</p>
        ) : (
          <div className="overflow-x-auto">
            <table className="table table-zebra table-sm">
              <thead>
                <tr>
                  <th>#</th>
                  <th className="text-left">Player</th>
                  <th className="text-right">Points</th>
                  <th className="text-right">Used</th>
                  <th className="text-right">Top 3</th>
                  <th className="text-right">Top 9</th>
                  <th className="text-right">Wins</th>
                </tr>
              </thead>
              <tbody>
                {rows.slice(0, 10).map((r) => (
                  <tr key={`${r.player_id}-${r.position}`}>
                    <td>{r.position}</td>
                    <td className="max-w-[180px] truncate" title={r.display_name}>
                      <Link
                        className="link link-hover"
                        href={`/players/${encodeURIComponent(r.player_id)}`}
                      >
                        {r.display_name}
                      </Link>
                    </td>
                    <td className="text-right">{fmtNum(r.total_points)}</td>
                    <td className="text-right">{r.used_count}</td>
                    <td className="text-right">{r.top3_count}</td>
                    <td className="text-right">{r.top9_count}</td>
                    <td className="text-right">{r.wins ?? 0}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  );
}

/* ---------- Page ---------- */
export default async function HomePage() {
  const res = await fetch(`${await baseUrl()}/api/home`, { cache: "no-store" });

  if (!res.ok) {
    return (
      <main className="space-y-6">
        <section className="card bg-base-200/60">
          <div className="card-body">
            <h1 className="card-title text-2xl">National Poker League</h1>
            <div className="alert alert-error mt-2">
              <span>
                Failed to load homepage data: {res.status} {res.statusText}
              </span>
            </div>
          </div>
        </section>
      </main>
    );
  }

  const data = (await res.json()) as HomeResp;
  const season = data.season_meta;

  const nplPlayers = data.leaderboards.npl.length;
  const hrlPlayers = data.leaderboards.hrl.length;

  return (
    <main className="space-y-8">
      {/* HERO */}
      <section className="card bg-base-200/60 shadow-md">
        <div className="card-body gap-6">
          <div className="flex flex-col items-start justify-between gap-4 md:flex-row md:items-center">
            <div className="space-y-1">
              <h1 className="card-title text-3xl">National Poker League</h1>
              <p className="text-sm text-base-content/70">
                Season {season.id}: <span className="font-medium">{season.label}</span>{" "}
                • {season.start_date} → {season.end_date}
              </p>
              <p className="text-xs text-base-content/60">
                Scoring method:{" "}
                {season.method === "BEST_X"
                  ? `Best ${season.cap_x} results count`
                  : "All results count"}{" "}
                · NPL &amp; High Roller League
              </p>
            </div>
            <div className="flex flex-wrap items-center gap-2">
              <Link className="btn btn-primary btn-sm md:btn-md" href="/leaderboards">
                View leaderboards
              </Link>
              <Link className="btn btn-outline btn-sm md:btn-md" href="/events">
                Browse events
              </Link>
            </div>
          </div>

          {/* Season stats */}
          <div className="stats stats-vertical sm:stats-horizontal border border-base-300 rounded-box mt-2">
            <div className="stat">
              <div className="stat-title">Season window</div>
              <div className="stat-value text-lg md:text-xl">
                {season.start_date}
              </div>
              <div className="stat-desc">Ends {season.end_date}</div>
            </div>
            <div className="stat">
              <div className="stat-title">Scoring</div>
              <div className="stat-value text-lg md:text-xl">
                {season.method === "BEST_X" ? `Best ${season.cap_x}` : "All"}
              </div>
              <div className="stat-desc">
                {season.method === "BEST_X"
                  ? "Only best results count"
                  : "Every result counts"}
              </div>
            </div>
            <div className="stat">
              <div className="stat-title">Players tracked</div>
              <div className="stat-value text-lg md:text-xl">
                {nplPlayers + hrlPlayers}
              </div>
              <div className="stat-desc">
                NPL: {nplPlayers} • HRL: {hrlPlayers}
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* MINI LEADERBOARDS */}
      <section className="grid gap-6 lg:grid-cols-2">
        <MiniLeaderboard
          title="Leaderboard — NPL"
          href="/leaderboards?league=npl"
          rows={data.leaderboards.npl}
        />
        <MiniLeaderboard
          title="Leaderboard — High Roller League"
          href="/leaderboards?league=hrl"
          rows={data.leaderboards.hrl}
        />
      </section>

      {/* TRENDING + GAINERS */}
      <section className="grid gap-6 lg:grid-cols-2">
        {/* Trending players */}
        <div className="card bg-base-200/60">
          <div className="card-body gap-4">
            <div className="flex items-center justify-between">
              <h2 className="card-title text-lg">Trending players</h2>
              <Link className="btn btn-outline btn-sm" href="/players">
                Browse players
              </Link>
            </div>
            {!data.trending_players.length ? (
              <p className="text-sm text-base-content/70">
                No trending data yet — once players start getting searched, they’ll
                appear here.
              </p>
            ) : (
              <ul className="menu bg-base-200/40 rounded-box">
                {data.trending_players.slice(0, 10).map((p) => (
                  <li
                    key={p.player_id}
                    className="flex items-center justify-between"
                  >
                    <Link href={`/players/${encodeURIComponent(p.player_id)}`}>
                      {p.display_name}
                    </Link>
                    <span className="badge badge-ghost text-xs">
                      {p.hits} views
                    </span>
                  </li>
                ))}
              </ul>
            )}
          </div>
        </div>

        {/* Biggest gainers */}
        <div className="card bg-base-200/60">
          <div className="card-body gap-4">
            <h2 className="card-title text-lg">Biggest gainers</h2>
            {!data.biggest_gainers.length ? (
              <p className="text-sm text-base-content/70">
                No recent leaderboard movements — check back after the next events.
              </p>
            ) : (
              <div className="overflow-x-auto">
                <table className="table table-zebra table-sm">
                  <thead>
                    <tr>
                      <th className="text-left">Player</th>
                      <th className="text-right">From</th>
                      <th className="text-right">To</th>
                      <th className="text-right">Δ</th>
                    </tr>
                  </thead>
                  <tbody>
                    {data.biggest_gainers.slice(0, 10).map((g) => (
                      <tr key={g.player_id}>
                        <td className="max-w-[200px] truncate" title={g.display_name}>
                          <Link
                            className="link link-hover"
                            href={`/players/${encodeURIComponent(g.player_id)}`}
                          >
                            {g.display_name}
                          </Link>
                        </td>
                        <td className="text-right">{g.from_pos}</td>
                        <td className="text-right">{g.to_pos}</td>
                        <td className="text-right">
                          {g.delta > 0 ? `+${g.delta}` : g.delta}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
          </div>
        </div>
      </section>

      {/* LATEST RESULTS */}
      <section className="card bg-base-200/60">
        <div className="card-body gap-4">
          <div className="flex items-center justify-between">
            <h2 className="card-title text-lg">Latest results</h2>
            <Link className="btn btn-outline btn-sm" href="/events">
              All events
            </Link>
          </div>

          {!data.latest_results.length ? (
            <p className="text-sm text-base-content/70">
              No recent results have been imported yet.
            </p>
          ) : (
            <div className="overflow-x-auto">
              <table className="table table-zebra table-sm">
                <thead>
                  <tr>
                    <th className="text-left">Date</th>
                    <th className="text-left">Event</th>
                    <th className="text-left">Winner</th>
                    <th className="text-right">Prize</th>
                    <th className="text-left">Link</th>
                  </tr>
                </thead>
                <tbody>
                  {data.latest_results.map((r) => (
                    <tr key={r.id}>
                      <td>{r.result_date ?? "—"}</td>
                      <td>{r.event_name ?? "—"}</td>
                      <td>{r.winner_name}</td>
                      <td className="text-right">{fmtGBP(r.prize_amount)}</td>
                      <td>
                        <Link
                          className="link link-hover"
                          href={`/#/result/${encodeURIComponent(r.id)}`}
                        >
                          View result
                        </Link>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>
      </section>

      {/* UPCOMING EVENTS */}
      <section className="card bg-base-200/60">
        <div className="card-body gap-4">
          <div className="flex items-center justify-between">
            <h2 className="card-title text-lg">Upcoming events</h2>
            <Link className="btn btn-outline btn-sm" href="/events">
              See calendar
            </Link>
          </div>

          {!data.upcoming_events.length ? (
            <p className="text-sm text-base-content/70">
              No upcoming events in the schedule right now.
            </p>
          ) : (
            <ul className="divide-y divide-base-300">
              {data.upcoming_events.map((e) => (
                <li
                  key={String(e.id)}
                  className="flex items-center justify-between py-2"
                >
                  <div className="max-w-xs truncate">
                    <div className="text-sm font-medium truncate">
                      {e.name || "—"}
                    </div>
                    <div className="text-xs text-base-content/60">
                      {e.start_date || "TBA"}
                    </div>
                  </div>
                  <Link
                    className="btn btn-sm btn-outline"
                    href={`/events/${encodeURIComponent(String(e.id))}`}
                  >
                    View
                  </Link>
                </li>
              ))}
            </ul>
          )}
        </div>
      </section>
    </main>
  );
}
