// src/app/players/page.tsx
import Link from "next/link";
import { headers } from "next/headers";

const PLACEHOLDER_AVATAR_URL = "/avatar-default.svg";
// put this file in `public/avatar-default.svg`

type PlayersSearchParams = {
  q?: string;
  page?: string;
};

type PlayersResponse = {
  meta: {
    page: number;
    pageSize: number;
    total: number;
    query: string;
  };
  rows: {
    id: string;
    name: string;
    avatar_url: string | null;
    consent: boolean; // currently unused, kept for future filtering
  }[];
};

async function apiFetch(pathWithQuery: string) {
  const h = await headers(); // Next 16: Promise

  const proto = h.get("x-forwarded-proto") ?? "http";
  const host = h.get("x-forwarded-host") ?? h.get("host");
  if (!host) throw new Error("Host header missing");

  const url = `${proto}://${host}${pathWithQuery}`;
  return fetch(url, { cache: "no-store" });
}

async function fetchPlayers(q: string, page: number): Promise<PlayersResponse> {
  const params = new URLSearchParams();
  if (q) params.set("q", q);
  params.set("page", String(page));
  params.set("pageSize", "24");

  const res = await apiFetch(`/api/players?${params.toString()}`);
  if (!res.ok) throw new Error("Failed to load players");
  return res.json();
}

export default async function PlayersIndex({
  searchParams,
}: {
  searchParams: Promise<PlayersSearchParams>;
}) {
  const sp = await searchParams;
  const q = (sp.q ?? "").trim();
  const page = Number(sp.page ?? 1) || 1;

  const data = await fetchPlayers(q, page);

  const totalPages =
    data.meta.pageSize > 0
      ? Math.max(1, Math.ceil(data.meta.total / data.meta.pageSize))
      : 1;

  const letters = "ABCDEFGHIJKLMNOPQRSTUVWXYZ".split("");

  return (
    <div className="space-y-6">
      {/* Header + search */}
      <section className="card bg-base-100 shadow-sm">
        <div className="card-body space-y-4">
          <div className="flex flex-wrap items-center justify-between gap-3">
            <div>
              <h1 className="card-title text-2xl">Players</h1>
              <p className="text-sm text-base-content/60">
                {data.meta.total.toLocaleString()} total players in National
                Poker League
              </p>
            </div>

            <div className="flex flex-wrap items-center gap-3 text-xs sm:text-sm text-base-content/60">
              <span>
                Page {data.meta.page} of {totalPages} · showing{" "}
                {Math.min(
                  data.meta.page * data.meta.pageSize,
                  data.meta.total
                ).toLocaleString()}{" "}
                of {data.meta.total.toLocaleString()}
              </span>

              <select
                name="sort"
                defaultValue="name"
                className="select select-bordered select-xs sm:select-sm"
                disabled
                aria-label="Sort players (more options coming soon)"
              >
                <option value="name">Name A–Z</option>
              </select>
            </div>
          </div>

          {/* Search form */}
          <form action="/players" className="flex flex-wrap gap-2">
            <input
              type="text"
              name="q"
              placeholder="Search players by name…"
              defaultValue={q}
              className="input input-bordered flex-1 min-w-[180px]"
            />
            <button className="btn btn-primary" type="submit">
              Search
            </button>
          </form>

          {/* Alphabet quick nav */}
          <div className="flex flex-wrap gap-1 text-xs text-base-content/60">
            {letters.map((letter) => {
              const isActive =
                q.length > 0 && q[0].toUpperCase() === letter.toUpperCase();

              const params = new URLSearchParams();
              params.set("q", letter);
              params.set("page", "1");

              return (
                <Link
                  key={letter}
                  href={`/players?${params.toString()}`}
                  className={`btn btn-ghost btn-xs ${
                    isActive ? "btn-active" : ""
                  }`}
                >
                  {letter}
                </Link>
              );
            })}
          </div>
        </div>
      </section>

      {/* Players list */}
      <section className="card bg-base-100 shadow-sm">
        <div className="card-body space-y-4">
          {data.rows.length === 0 ? (
            <div className="flex flex-col items-start gap-2">
              <p className="font-medium">No players found.</p>
              {q ? (
                <p className="text-sm text-base-content/60">
                  No matches for “{q}”. Try a shorter name, a different
                  spelling, or search by first or last name.
                </p>
              ) : (
                <p className="text-sm text-base-content/60">
                  There are currently no players to display.
                </p>
              )}
            </div>
          ) : (
            <ul className="grid gap-1 md:grid-cols-2">
              {data.rows.map((p) => {
                const avatarSrc = p.avatar_url || PLACEHOLDER_AVATAR_URL;
                const initials =
                  p.name
                    ?.split(" ")
                    .filter(Boolean)
                    .slice(0, 2)
                    .map((n) => n[0])
                    .join("") ?? "?";

                // Placeholder badges – later you can drive this from real data
                const placeholderBadges = [
                  "GUKPT Winner",
                  "NPL Winner",
                  "25/50 Winner",
                  "Current Season #1",
                ];

                return (
                  <li
                    key={p.id}
                    className="rounded-xl hover:bg-base-200/40 transition-colors"
                  >
                    <Link
                      href={`/players/${p.id}`}
                      className="flex items-center gap-3 px-4 py-3"
                    >
                      <div className="avatar">
                        <div className="w-10 rounded-full bg-base-200 overflow-hidden flex items-center justify-center text-sm font-semibold">
                          {/* eslint-disable-next-line @next/next/no-img-element */}
                          {avatarSrc ? (
                            <img
                              src={avatarSrc}
                              alt={p.name ?? ""}
                              className="w-full h-full object-cover"
                            />
                          ) : (
                            <span>{initials}</span>
                          )}
                        </div>
                      </div>

                      <div className="flex-1 min-w-0">
                        <p className="truncate font-medium">{p.name}</p>

                        <div className="mt-1 flex flex-wrap gap-1">
                          {placeholderBadges.slice(0, 3).map((badge) => (
                            <span
                              key={badge}
                              className="badge badge-ghost badge-xs border border-base-300 text-[0.65rem]"
                            >
                              {badge}
                            </span>
                          ))}
                        </div>
                      </div>

                      <span className="hidden sm:inline-flex items-center text-xs text-base-content/60">
                        View
                      </span>
                    </Link>
                  </li>
                );
              })}
            </ul>
          )}

          {/* Pagination footer */}
          <div className="flex flex-wrap items-center justify-between gap-3 pt-2 text-xs sm:text-sm">
            <span className="text-base-content/60">
              Page {data.meta.page} of {totalPages} ·{" "}
              {data.meta.total.toLocaleString()} total players
            </span>
            <div className="flex gap-2">
              {data.meta.page > 1 && (
                <Link
                  href={`/players?${new URLSearchParams({
                    q,
                    page: String(page - 1),
                  }).toString()}`}
                  className="btn btn-outline btn-xs sm:btn-sm"
                >
                  Prev
                </Link>
              )}
              {data.meta.page < totalPages && (
                <Link
                  href={`/players?${new URLSearchParams({
                    q,
                    page: String(page + 1),
                  }).toString()}`}
                  className="btn btn-outline btn-xs sm:btn-sm"
                >
                  Next
                </Link>
              )}
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}
